const fox = (prefixo, nomeBot, patt, emoji, nomeDono, pushname, sender) => {
  return `
╭────────────────
│               *INFO DO BOT*
│  ╭──────────────
│  │Nome: *${NomeBot}*
│  │Prefixo: *${prefixo}*
│  │Nome Do Dono: *${nomeDono}*
│  │Numero Do Dono: *${numeroDono}*
│  ╰──────────────
│              *USUÁRIO*
│ ╭──────────────      
│ │Nome: *${pushname}*
│ │Numero: *${sender.split("@")[0]}*
│ │Patente:  ${patt}
│ ╰──────────────
│          *BRINCADEIRAS*
│╭───────────────
││${prefixo}*Cassino*
││${prefixo}*Anagrama*
││${prefixo}*Cartafofa*
││${prefixo}*Jogodaforca*
││${prefixo}*resetforca*
││${prefixo}*gay*
││${prefixo}*feio*
││${prefixo}*matar*
││${prefixo}*bebado*
││${prefixo}*vesgo*
││${prefixo}*corno*
││${prefixo}*beijo*
││${prefixo}*gostoso*
││${prefixo}*gado*
││${prefixo}*gostosa*
││${prefixo}*dogolpe*
││${prefixo}*chutar*
││${prefixo}*tapa*
││${prefixo}*shipo*
││${prefixo}*casal*
││${prefixo}*nazista*
││${prefixo}*rankgay*
││${prefixo}*rankgado*
││${prefixo}*rankcorno*
││${prefixo}*rankgostosos*
││${prefixo}*rankgostosas*
││${prefixo}*rankotakus*
││${prefixo}*ranknazista*
││${prefixo}*rankpau*
│╰───────────────
│            *GRUPOS*
│ ╭───────────────
│ │${prefixo}*Repetir*      
│ │${prefixo}*Calculadora*
│ │${prefixo}*Nomegp*
│ │${prefixo}*Descgp*
│ │${prefixo}*Fotogp*
│ │${prefixo}*Totag*
│ │${prefixo}*Hidetag*
│ │${prefixo}*Linkgp*
│ │${prefixo}*Promover*
│ │${prefixo}*Rebaixar*
│ │${prefixo}*Ban*
│ │${prefixo}*Add*
│ ╰───────────────
│          *FIGURINHAS*
│╭───────────────
││${prefixo}*F*
││${prefixo}*Fig*
││${prefixo}*Figura*
││${prefixo}*figurinha*
││${prefixo}*Stickergif*
││${prefixo}*figgif*
│╰───────────────
│             *VIP*
│╭───────────────
││${prefixo}*Serpremium*
││${prefixo}*Addpremium*
││${prefixo}*Delpremium*
││${prefixo}*Premiumlist*
│╰───────────────
│         *OUTROS*
│╭───────────────
││${prefixo}*Enquete*
││${prefixo}*Ping*
││${prefixo}*Reagir*
│╰───────────────
│           *LEVEL*
│╭───────────────
││${prefixo}*Leveling*
││${prefixo}*Level*
││${prefixo}*Ganharlevel*
││${prefixo}*Ganharxp*
│╰─────────────── 
│           *DONO*
│╭───────────
││${prefixo}*entrar/link*
││${prefixo}*sair*
││${prefixo}*Reiniciar*
││${prefixo}*dono*
││${prefixo}*report/sugestão*
╰────────────────`
}
exports.fox = fox