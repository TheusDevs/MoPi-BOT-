/*  Bot Sendo feito por: Theusϟ.mp? 
    está 65% pronto falta muitas funções e correções de bugs
    caso queira usar o bot fale com o Matheus
    

*/
//   >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<
const {
default: AnyWASocket,
MessageType,
Presence,
GroupSettingChange,
WA_MESSAGE_STUB_TYPES,
Mimetype,
relayWAMessage,
makeInMemoryStore,
useSingleFileAuthState,
useMultiFileAuthState,
BufferJSON, 
jidDecode, 
DisconnectReason, 
fetchLatestBaileysVersion,
downloadContentFromMessage,
delay,
WA_DEFAULT_EPHEMERAL ,
generateWAMessageFromContent ,
proto ,
generateWAMessageContent ,
generateWAMessage ,
prepareWAMessageMedia ,
areJidsSameUser ,
getContentType

// MÓDULOS NPM
} = require("@adiwajshing/baileys")
const fs = require("fs")
const chalk = require("chalk")
const P = require("pino")
const p = require("pino")
const Pino = require("pino")
const axios = require('axios')
const clui = require("clui")
const util = require("util")
const fetch = require("node-fetch")
const yts = require("yt-search")
const Crypto = require("crypto")
const ff = require('fluent-ffmpeg')
const webp = require("node-webpmux")
const path = require("path")
const cheerio = require("cheerio")
const cfonts = require("cfonts")
const BodyForm = require("form-data")
const mimetype = require("mime-types")
const speed = require("performance-now")
const { exec, spawn, execSync } = require("child_process")
const { color } = require("./database/arquivos/lib/color")
const { fetchJson } = require("./database/arquivos/lib/fetcher")
const { fromBuffer } = require("file-type")
const { tmpdir } = require("os")
const { palavrasANA } = require('./database/funções/anagrama/jogos.js');
const { getLevelingXp, getLevelingLevel, getLevelingId, Telesticker, addLevelingXp, addLevelingLevel, addLevelingId, smsg, tanggal, formatDate, getTime, isUrl, sleep, clockString, runtime, jsonformat, format, parseMention } = require('./database/funções/myfunc.js')
let _level = JSON.parse(fs.readFileSync('./database/funções/level.json'))
let leveling = JSON.parse(fs.readFileSync('./database/funções/leveling.json'))
const antinotas = JSON.parse(fs.readFileSync('./database/funções/grupos/antinotas.json'))
const sotoy = JSON.parse(fs.readFileSync('./database/funções/sotoy.json'));
const premium = JSON.parse(fs.readFileSync('./database/funções/usuarios/premium.json'));
const setting = require('./database/funções/funcsion.js')
const forca = JSON.parse(fs.readFileSync('database/funções/grupos/forca.json'))
const puppet = JSON.parse(fs.readFileSync('database/funções/grupos/puppet_forca.json'))
const registros = JSON.parse(fs.readFileSync('./database/funções/usuarios/registros.json'))

// CONST DATA HORA E MOMENTO
const moment = require("moment-timezone")
const hora = moment.tz("America/Sao_Paulo").format("HH:mm:ss")
const data = moment.tz("America/Sao_Paulo").format("DD/MM/YY")

// CONST DE FUNÇÕES SPAM E GRUPOS
const { addFlod , isFlod } = require('./database/funções/spam.js')
const { isFiltered, addFilter } = require('./database/funções/spam.js')
const palavra = JSON.parse(fs.readFileSync('./database/funções/grupos/palavras.json'))
const palavrao = JSON.parse(fs.readFileSync('./database/funções/grupos/palavrao.json'))

// ENVIAR LISTA EM BAIXO





//EM CIMA

// CONST DO NOME BOT, DONO ETC
const { banner, banner2, getGroupAdmins, getBuffer, getExtension, getRandom, upload, log } = require("./database/lib/functions.js")
const config = JSON.parse(fs.readFileSync("./database/files/config/data.json"))
const dono = config.numeroDono
prefix = config.prefix
prefixo = config.prefix
nomeBot = config.nomeBot
NomeBot = config.nomeBot
numeroBot = config.numeroBot
nomeDono = config.nomeDono
NomeDono = config.nomeDono
emoji = config.emoji
numeroDono = config.numeroDono
reagir = config.reação

//CONST FOTOS ALEATÓRIAS 
const fotoaleatoria = JSON.parse(fs.readFileSync('./database/files/fotos/teste.json'))
result = fotoaleatoria.result

// CONST FOTO DO MENU
const logos = JSON.parse(fs.readFileSync('./database/files/fotos/logos.json'))
ping = logos.ping
logo2 = logos.menu
meno2 = logos.menu2
level = logos.level
logo5 = logos.logo5
logo6 = logos.logo6
logo7 = logos.logo7

//CONST LOGO DO THEUSϞ.MP?
//const fotos = JSON.parse(fs.readFileSync('./database/files/fotos'))
//logo01 = theus.jpg
const blabla = fs.readFileSync('./database/files/fotos/theus.jpg');
// CONST DE IMPORTAR O MENU
const { menu } = require('./database/files/menu/menu.js');
const { menu2 } = require('./database/files/menu/menu2.js');
// INCIO DA CONEXÃO-DO-BOT 
async function startmopi () {
const store = makeInMemoryStore({ logger: P().child({ level: "debug", stream: "store" }) })

// CONST PARA GERAR O QRCODE E CONEXÃO 
const { state, saveCreds } = await useMultiFileAuthState('./database/qrcode/aqui')
console.log(banner.string)
console.log(banner2.string)
const theus = AnyWASocket({
logger: P({ level: "silent" }),
printQRInTerminal: true,
auth: state
})
theus.ev.on('creds.update', saveCreds);
store.bind(theus.ev)
theus.ev.on("chats.set", () => {
console.log("Tem conversas", store.chats.all())
})
theus.ev.on("contacts.set", () => {
console.log("Tem contatos", Object.values(store.contacts))
})
theus.ev.on("connection.update", (update) => {
const { connection, lastDisconnect } = update
if(connection === "close") {
const shouldReconnect = (lastDisconnect.error)?.output?.statusCode !== DisconnectReason.loggedOut
console.log("Conexão fechada devido a", lastDisconnect.error, "Tentando reconectar...", shouldReconnect);
if(shouldReconnect) {
startmopi()
}
} else if(connection === "open") {
console.log(`${color(`Bot Conectado Com Sucesso!`,'white')}`)
}
})
console.log(`${color(`Bom Aproveito Do MoPi Bot Fico Feliz.`,'cyan')}`)
console.log(`${color(`Passa no canal: Theusϟ.mp?`,'white')}`)

// INÍCIO DA CONEXÃO 

theus.ev.on("messages.upsert", async m => {
try {
const info = m.messages[0]
if (!info.message) return 
await theus.readMessages([info.key]);
if (info.key && info.key.remoteJid == "status@broadcast") return
const altpdf = Object.keys(info.message)
const type = altpdf[0] == "senderKeyDistributionMessage" ? altpdf[1] == "messageContextinfo" ? altpdf[2] : altpdf[1] : altpdf[0]
global.prefixo

// CONST IMPORTANTE

const msg = m.messages[0]
if (!msg.message) return 

const getBuffer = (url, options) => new Promise(async (resolve, reject) => { 
options ? options : {}
await axios({method: "get", url, headers: {"DNT": 1, "Upgrade-Insecure-Request": 1}, ...options, responseType: "arraybuffer"}).then((res) => {
resolve(res.data)
}).catch(reject)
})
const getRandom = (ext) => {
return `${Math.floor(Math.random() * 10000)}${ext}`
}
const getExtension = async (type) => {
return await mimetype.extension(type)
}
const content = JSON.stringify(info.message)
const from = info.key.remoteJid
var body = (type === 'conversation') ? msg.message.conversation : (type == 'imageMessage') ? msg.message.imageMessage.caption : (type == 'videoMessage') ? msg.message.videoMessage.caption : (type == 'extendedTextMessage') ? msg.message.extendedTextMessage.text : (type == 'buttonsResponseMessage') ? msg.message.buttonsResponseMessage.selectedButtonId : (type == 'listResponseMessage') ? msg.message.listResponseMessage.singleSelectReply.selectedRowId : (type == 'templateButtonReplyMessage') ? msg.message.templateButtonReplyMessage.selectedId : (type === 'messageContextInfo') ? (msg.message.buttonsResponseMessage?.selectedButtonId || msg.message.listResponseMessage?.singleSelectReply.selectedRowId || msg.text) : ''                                                                           
budy = (type === 'conversation') ? info.message.conversation : (type === 'extendedTextMessage') ? info.message.extendedTextMessage.text : ''
const args = body.trim().split(/ +/).slice(1)
const isCmd = body.startsWith(prefixo)
const mopi = isCmd ? body.slice(1).trim().split(/ +/).shift().toLocaleLowerCase() : null
const comando = isCmd ? body.slice(1).trim().split(/ +/).shift().toLocaleLowerCase() : null
//bady = (type === "conversation") ? info.message.conversation : (type == "imageMessage") ? info.message.imageMessage.caption : (type == "videoMessage") ? info.message.videoMessage.caption : (type == "extendedTextMessage") ? info.message.extendedTextMessage.text : (info.message.listResponseMessage && info.message.listResponseMessage.singleSelectenviar.selectedRowId) ? info.message.listResponseMessage.singleSelectenviar.selectedRowId: ""
budy = (type === "conversation") ? info.message.conversation : (type === "extendedTextMessage") ? info.message.extendedTextMessage.text : ""
button = (type == "buttonsResponseMessage") ? info.message.buttonsResponseMessage.selectedDisplayText : ""
button = (type == "buttonsResponseMessage") ? info.message.buttonsResponseMessage.selectedButtonId : ""
listMessage = (type == "listResponseMessage") ? info.message.listResponseMessage.title : ""
var pes = (type === "conversation" && info.message.conversation) ? info.message.conversation : (type == "imageMessage") && info.message.imageMessage.caption ? info.message.imageMessage.caption : (type == "videoMessage") && info.message.videoMessage.caption ? info.message.videoMessage.caption : (type == "extendedTextMessage") && info.message.extendedTextMessage.text ? info.message.extendedTextMessage.text : ""
bidy =  budy.toLowerCase()
//onst stream = await downloadContentFromMessage(mediakey, MediaType)

//OUTRAS FUNÇÕES
const getFileBuffer = async (mediakey, MediaType) => { 
const stream = await downloadContentFromMessage(mediakey, MediaType)
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
return buffer
}
const mentions = (teks, memberr, id) => {
(id == null || id == undefined || id == false) ? theus.sendMessage(from, {text: teks.trim(), mentions: memberr}) : theus.sendMessage(from, {text: teks.trim(), mentions: memberr})
}
const getGroupAdmins = (participants) => {
admins = []
for (let i of participants) {
if(i.admin == "admin") admins.push(i.id)
if(i.admin == "superadmin") admins.push(i.id)
}
return admins
}
const messagesC = pes.slice(0).trim().split(/ +/).shift().toLowerCase()
const arg = body.substring(body.indexOf(" ") + 1)
const numeroBot = theus.user.id.split(":")[0]+"@s.whatsapp.net"
const argss = body.split(/ +/g)
const testat = body
const ants = body
const isGroup = info.key.remoteJid.endsWith("@g.us")
const tescuk = ["0@s.whatsapp.net"]
const q = args.join(" ")
const isUrl = (url) => {
return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}

// CONST DE GRUPO E IMPORTAÇÕES 
const sender = isGroup ? info.key.participant : info.key.remoteJid
const pushname = info.pushName ? info.pushName : ""
const groupMetadata = isGroup ? await theus.groupMetadata(from) : ""
const groupName = isGroup ? groupMetadata.subject : ""
const groupDesc = isGroup ? groupMetadata.desc : ""
const groupMembers = isGroup ? groupMetadata.participants : ""
const groupAdmins = isGroup ? getGroupAdmins(groupMembers) : ""
const canal = config.canal
const grupo = config.grupo
const participants = isGroup ? await groupMetadata.participants : ''
const text = args.join(" ")
const c = args.join(' ')
const enviar = (texto) => {
theus.sendMessage(from, { text: texto }, {quoted: info})
}

/********** VCARD DO DONO **********/
const vcard = `BEGIN:VCARD\n`
+ `VERSION:3.0\n`
+ `FN:Tobi\n`
+ `ORG:Lolizita-BOT;\n` 
+ `TEL;type=CELL;type=VOICE;waid=559481417512:+55 94 8141-7512\n` 
+ `END:VCARD`

// MEUS SELOS

//selo com nome do usuario
const selo = {key : {participant : '0@s.whatsapp.net'},message: {contactMessage:{displayName: `${pushname}`}}}

// Selo loja1
const selo1 = {"key": {"fromMe": false,"participant":"0@s.whatsapp.net", "remoteJid": "557598293339@g.us" }, "message": {orderMessage: {itemCount: 2007,status: 4, thumbnail: fs.readFileSync(`./database/files/fotos/theus.jpg`) ,message: `Nick : ${pushname}`,surface: 100, sellerJid: "0@s.whatsapp.net"}}}

// Selo nome bot
const selo2 = { key: {participant: `0@s.whatsapp.net`, mentionedJid: `Theus¿`, ...(m.from ?{ remoteJid: `${m.from}` } : {}) },message: {"extendedTextMessage": {"text":`BOT-MoPi` }} }     
  
// Selo grupo  
const selogp = { key: {fromMe: false,participant: "0@s.whatsapp.net",remoteJid: "0@s.whatsapp.net"},message: {"groupInviteMessage": {"groupJid": "6288213840883-1616169743@g.us","inviteCode": "VERIFICADO","groupName": "©MoPi", "caption": `${hora} ${pushname}`, 'jpegThumbnail': fs.readFileSync(`./database/files/fotos/selo.jpg`)}}}; 

// Selo video
const selovid = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289643739077-1613049930@g.us" } : {}) }, message: { "videoMessage": { "title": `Usuario: ${pushname}`, "h": `Usuario: ${pushname}`, 'duration': '99999', 'caption': `Usuario: ${pushname}`, 'jpegThumbnail': fs.readFileSync(`./database/files/fotos/selo.jpg`), } } };    

// Selo documento
const selodoc = { key : { participant : '0@s.whatsapp.net' }, message: { documentMessage: { title: `Usuario: ${pushname}`, jpegThumbnail: fs.readFileSync(`./database/files/fotos/theus.jpg`) } } };

// Selo gif
const selogif = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6289643739077-1613049930@g.us" } : {}) }, message: { "videoMessage": { "title": `Usuario: ${pushname}`, "h": `Usuario: ${pushname}`, 'duration': '99', 'gifPlayback': 'true', 'caption': `Usuario: ${pushname}`, 'jpegThumbnail': fs.readFileSync(`./database/files/fotos/selo.jpg`) } } };
//
//selo loja2
const seloloja = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast"} : {}) }, message: { "productMessage": { "product": { "productImage":{ "mimetype": "image/jpeg", "jpegThumbnail": fs.readFileSync(`./database/files/fotos/selo.jpg`) }, "title": `Usuario: ${pushname}`, "description": "ngab", "currencyCode": "IDR", "priceAmount1000": "50.000", "retailerId": "Self Bot", "productImageCount": 0 }, "businessOwnerJid": `0@s.whatsapp.net` } } };

// Selo catálogo 
const selocat ={"key": { "fromMe": false,"participant":"0@s.whatsapp.net", "remoteJid": "556181496039-1625944593@g.us" }, "message": {orderMessage: {itemCount: `0`,status: 200, thumbnail: fs.readFileSync(`./database/files/fotos/selo.jpg`), surface: 200, message: `⊳ Usuario ${pushname}`, orderTitle: '©BOT-MoPi', sellerJid: '0@s.whatsapp.net'}}, contextInfo: {"forwardingScore":999999,"isForwarded":true},sendEphemeral: true}; 

// Selo foto 
const selofoto = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg","caption": "BOT-MoPi", 'jpegThumbnail': fs.readFileSync(`./database/files/fotos/selo.jpg`)}}} 
seloimage = selofoto 
seloimg = selofoto; 

// Selo status 
const selostt = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "imageMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "image/jpeg","caption": `${hora} ${pushname}!`, 'jpegThumbnail': fs.readFileSync(`./database/files/fotos/selo.jpg`)}}} 
selostatus = selostt 
selostat = selostt

// Selo view 
const seloview = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { "viewOnceMessage": { "jpegThumbnail": fs.readFileSync(`./database/files/fotos/selo.jpg`)} } } 

// Selo localização 
const seloloc = {
key : {
participant : '0@s.whatsapp.net'
},
message: {
liveLocationMessage: {
caption: `Usuario: ${pushname}`,
jpegThumbnail: fs.readFileSync(`./database/files/fotos/selo.jpg`)
}
}
};

// Selo conta
const selocont = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: '16504228206@s.whatsapp.net' } : {}) }, message: { "contactMessage": { "displayName": `${pushname}`, "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:XL;${pushname},;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, "jpegThumbnail":fs.readFileSync(`./database/files/fotos/selo.jpg`)}}};

// Selo online
const seloOn = { key: {fromMe: false,participant: "0@s.whatsapp.net",remoteJid: "0@s.whatsapp.net"},message: {"groupInviteMessage": {"groupJid": "6288213840883-1616169743@g.us","inviteCode": "https://chat.whatsapp.com/JiXC3HsAgZs2Ry8mcq75iG","groupName": `${NomeBot}`, "caption": `Serviço ativado`, 'jpegThumbnail': fs.readFileSync(`./database/files/fotos/selo.jpg`)}}}

// Selo offiline
const seloOff = { key: {fromMe: false,participant: "0@s.whatsapp.net",remoteJid: "0@s.whatsapp.net"},message: {"groupInviteMessage": {"groupJid": "6288213840883-1616169743@g.us","inviteCode": "https://chat.whatsapp.com/JiXC3HsAgZs2Ry8mcq75iG","groupName": `${NomeBot}`, "caption": `Serviço desativado`, 'jpegThumbnail': fs.readFileSync(`./database/files/fotos/selo.jpg`)}}}

// Selo Tempo online do bot
const selotempoonline = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "6283136505591-1614953337@g.us" } : {}) }, message: { "documentMessage": { "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc", "mimetype": "application/octet-stream", "title": `「 Tempo de atividade: 」\n${runtime(process.uptime())}\n\n`, "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=", "fileLength": "28777", "height": 1080, "width": 1079, "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=", "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=", "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69", "mediaKeyTimestamp": "1610993486", "jpegThumbnail": fs.readFileSync(`./database/files/fotos/selo.jpg`)}}}
  
 //
//*************[ VERIFICADO ]**************//
const selo66 = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ... {}}, message: { "contactMessage": { "displayName": `${pushname}`, "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:XL;${pushname},;;;\nFN:${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD` }}}
//*******************************************//
 const selomp = fs.readFileSync('./database/files/fotos/selo.jpg')
  //FIM DOS SELOS
  


const { fox  } = require('./database/files/menu/theus.js');
//*******************************************//
// CONSTS DE GRUPO
const isAntiNotas = isGroup ? antinotas.includes(from) : false
const isLevelingOn = isGroup ? leveling.includes(from) : false
const isPalavrao = isGroup ? palavrao.includes(from) : false	
const isPremium = premium.includes(sender)
const isRegistro = registros.includes(sender)
const quoted = info.quoted ? info.quoted : info
const mime = (quoted.info || quoted).mimetype || ""
const isBot = info.key.fromMe ? true : false
const isBotGroupAdmins = groupAdmins.includes(numeroBot) || false
const isGroupAdmins = groupAdmins.includes(sender) || false 
const isOwner = sender.includes(numeroDono)
const groupId = isGroup ? groupMetadata.jid : ''
banChats = true
const allForcaId = []
for(let obj of forca) allForcaId.push(obj.id)
const isPlayForca = allForcaId.indexOf(sender) >= 0 ? true : false

async function randompalavra() {
    return new Promise(async (resolve, reject) => {
fetch('https://www.palabrasaleatorias.com/palavras-aleatorias.php?fs=1&fs2=0&Submit=Nova+palavra',).then(async function (res, err) {
if(err) reject(err)    
var $ = cheerio.load(await res.text())
resolve($('body > center > center > table:nth-child(4) > tbody > tr > td > div')[0].children[0].data)
})
    }) 
}

var budy2 = budy.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, "");
const command = isCmd ? body.slice(1).trim().split(/ +/).shift().toLocaleLowerCase() : null


// CONST TIPO DE LINGUAGEM 
const isImage = type == "imageMessage"
const isVideo = type == "videoMessage"
const isAudio = type == "audioMessage"
const isSticker = type == "stickerMessage"
const isContact = type == "contactMessage"
const isLocation = type == "locationMessage"
const isProduct = type == "productMessage"
const isMedia = (type === "imageMessage" || type === "videoMessage" || type === "audioMessage")
typeMessage = body.substr(0, 50).replace(/\n/g, "")
if (isImage) typeMessage = "Image"
else if (isVideo) typeMessage = "Video"
else if (isAudio) typeMessage = "Audio"
else if (isSticker) typeMessage = "Sticker"
else if (isContact) typeMessage = "Contact"
else if (isLocation) typeMessage = "Location"
else if (isProduct) typeMessage = "Product"
const isQuotedMsg = type === "extendedTextMessage" && content.includes("textMessage")
const isQuotedImage = type === "extendedTextMessage" && content.includes("imageMessage")
const isQuotedVideo = type === "extendedTextMessage" && content.includes("videoMessage")
const isQuotedDocument = type === "extendedTextMessage" && content.includes("documentMessage")
const isQuotedAudio = type === "extendedTextMessage" && content.includes("audioMessage")
const isQuotedSticker = type === "extendedTextMessage" && content.includes("stickerMessage")
const isQuotedContact = type === "extendedTextMessage" && content.includes("contactMessage")
const isQuotedLocation = type === "extendedTextMessage" && content.includes("locationMessage")
const isQuotedProduct = type === "extendedTextMessage" && content.includes("productMessage")

//CONST DAR BOM DIA, BOA MADRUGADA, BOA TARDE E BOA NOITE

const time2 = moment().tz('America/Sao_Paulo').format('HH:mm:ss')
if(time2 > "00:00:00"){
var tempo = 'BOA MADRUGADA' 
} 
if(time2 > "05:30:00"){
var tempo = 'BOM DIA' 
}
if(time2 > "12:00:00"){
var tempo = 'BOA TARDE' 
}
if(time2 > "19:00:00"){
var tempo = 'BOA NOITE' 
}

// FUNÇÕES DE ANTI TEXTO

if(isAntiNotas && body.toString().match(/(💳|💎|💸|💵|💷|💶|🪙|💰|🤑|⚖️)/gi) && isBotGroupAdmins) {
if(type == 'stickerMessage') return
let verificar = body.toString().match(/(💳|💎|💸|💵|💷|💶|🪙|💰|🤑|⚖️)/gi)
if (verificar && body.length < 100) return  
await theus.sendMessage(from, {text: '*mensagem proibida detectada, banindo...*'}, {quoted: m})
setTimeout(async function () {
theus.groupParticipantsUpdate(from, [sender], 'remove')
}, 1000)
}

// FUNÇÕES DE LEVEL
const nivelAtual = getLevelingLevel(sender)
var patt = 'Graduado I '
if (nivelAtual === 1) {patt = 'Graduado  I ' } else if (nivelAtual === 2) {patt = 'Graduado II '} else if (nivelAtual === 3) {patt = 'Graduado  III '} else if (nivelAtual === 4) {patt = 'Graduado  IV  '} else if (nivelAtual === 5) {patt = 'Graduado  V '} else if (nivelAtual === 6) {patt = 'Oficiais Subalternos I'} else if (nivelAtual === 7) {patt = 'Oficiais Subalternos II'} else if (nivelAtual === 8) {patt = 'Oficiais Subalternos III'} else if (nivelAtual === 9) {patt = 'Oficiais Subalternos IV'} else if (nivelAtual === 10) {patt = 'Oficiais Subalternos V'} else if (nivelAtual === 11) {patt = 'Oficiais Intermediários I'} else if (nivelAtual === 12) {patt = 'Oficiais Intermediários II'} else if (nivelAtual === 13) {patt = 'Oficiais Intermediários III'} else if (nivelAtual === 14) {patt = 'Oficiais Intermediários IV'} else if (nivelAtual === 15) {patt = 'Oficiais Intermediários V'} else if (nivelAtual === 16) {patt = 'Oficiais Superioses I'} else if (nivelAtual === 17) {patt = 'Oficiais Superioses II'} else if (nivelAtual === 18) {patt = 'Oficiais Superioses III'} else if (nivelAtual === 19) {patt = 'Oficiais Superioses IV'} else if (nivelAtual === 20) {patt = 'Oficiais Superioses V'} else if (nivelAtual === 21) {patt = 'Major I '} else if (nivelAtual === 22) {patt = 'Major II '} else if (nivelAtual === 23) {patt = 'Major III '} else if (nivelAtual === 24) {patt = 'Major IV '} else if (nivelAtual === 25) {patt = 'Major V '} else if (nivelAtual === 26) {patt = 'Tenente Coronel I '} else if (nivelAtual === 27) {patt = 'Tenente Coronel II '} else if (nivelAtual === 28) {patt = 'Tenente Coronel III '} else if (nivelAtual === 29) {patt = 'Tenente Coronel IV '} else if (nivelAtual === 30) {patt = 'Tenente Coronel V '} else if (nivelAtual === 31) {patt = 'Coronel I '} else if (nivelAtual === 32) {patt = 'Coronel II '} else if (nivelAtual === 33) {patt = 'Coronel III '} else if (nivelAtual === 34) {patt = 'Coronel IV '} else if (nivelAtual === 35) {patt = 'Coronel V '} else if (nivelAtual === 36) {patt = 'Oficiais Generais I'} else if (nivelAtual === 37) {patt = 'Oficiais Generais II'} else if (nivelAtual === 38) {patt = 'Oficiais Generais III'} else if (nivelAtual === 39) {patt = 'Oficiais Generais IV'} else if (nivelAtual === 40) {patt = 'Oficiais Generais V'} else if (nivelAtual > 41) {patt = 'O Grande Marechal 🫡'}

// FUNÇÕES DA ANAGRAMA

if(isGroup && fs.existsSync(`./database/funções/anagrama/anagrama-${from}.json`)){
let dataAnagrama = JSON.parse(fs.readFileSync(`./database/funções/anagrama/anagrama-${from}.json`))
if(budy.slice(0,4).toUpperCase() == dataAnagrama.original.slice(0,4).toUpperCase() && budy.toUpperCase() != dataAnagrama.original) return enviar('está perto')
xp = Math.floor(Math.random() * 14) + 3000
if(budy.toUpperCase() == dataAnagrama.original) { theus.sendMessage(from, {text: `parabéns ${pushname} 🥳 você ganhou o jogo\nPalavra : ${dataAnagrama.original}\nIniciando o proximo jogo em 5 segundos...`}, {"mentionedJid": [sender]}), fs.unlinkSync(`./database/funções/anagrama/anagrama-${from}.json`)		
addLevelingXp(sender, xp)
recompensa = `Você Mereceu Aqui Vai Um Bonus\nVocê ganhou ${xp} em *xp*`
enviar(recompensa)
		setTimeout(async() => {
fs.writeFileSync(`./database/funções/anagrama/anagrama-${from}.json`, `${JSON.stringify(palavrasANA[Math.floor(Math.random() * palavrasANA.length)])}`)
let dataAnagrama2 = JSON.parse(fs.readFileSync(`./database/funções/anagrama/anagrama-${from}.json`))
theus.sendMessage(from, {text:`
╭═─────── ⟮ ⭕ ⟯ ───────═
┃               Descubra A Palavra 
┃
┃               ANAGRAMA: ${dataAnagrama2.embaralhada}
┃
┃               DICA: ${dataAnagrama2.dica}
╰──────── ⟮ ⭕ ⟯ ─────────═
`}) 
}, 5000)
}}

// FUNÇÕES XP
if (isGroup) {
const currentLevel = getLevelingLevel(sender)
const checkId = getLevelingId(sender)
try {
if (currentLevel === undefined && checkId === undefined) addLevelingId(sender)
const amountXp = Math.floor(Math.random() * 10) + 500
const requiredXp = 5000 * (Math.pow(2, currentLevel) - 1)
const getLevel = getLevelingLevel(sender)
addLevelingXp(sender, amountXp)
if (requiredXp <= getLevelingXp(sender)) {
addLevelingLevel(sender, 1)
}
} catch (err) {
console.error(err)
}
}

/********** MENSAGENS DO BOT **********/
var replys = ["[ ! ] Aguarde amigo, estou fazendo...", "Vai beber uma água, ja estou terminando de enviar..", "㋡ Opa, calma ae, tô enviando já!!", "❬❗❭ Aguarde 5 segundos", "☬ Seu pedido é uma ordem companheiro(a), Enviando...", "ههههه𓅂 Oi filho de Deus, calma ae, tô terminando de fazer..", "Oi princesa, já estou preparando pra enviar, Aguarde..", "Salve mano, só aguarde um pouquinho que já estou enviando!!", "Aquieta o coração amigo, já estou enviando!", "Espere sentado que estou enviando!", "Pisa no freio aí amigo, tô enviando já!", "Foi daqui que pediram comando? Ta chegando...", "Oq vc ñ pede chorando, que eu não faço sorrindo, enviando já!", "Em 365 dias úteis termino o comando kkkk meme, to enviando!", "Não precisa gritar, já ouvi e tô enviando seu pedido!", "Aproveita que tô terminando aqui e beba água, hidrate-se!", "Seu pedido é uma ordem, terminando patrão!", "Manda quem pode, obedece quem tem juízo. Já tô enviando...", "Jaja está na mão amigo, aguarde um instante!", "Quem espera, sempre alcança","Tô enviando já amigão!"]
var replys_mopi= replys[Math.floor(Math.random() *  replys.length)] 

  
  // REPOSTAS DO BOT
resposta = {
aguarde: `${replys_mopi}`,
erro: `Ocorreu Um Erro Inesperado🥺`,
admin: `Membros comuns não tem permissão para usar este comando`,
botadm: `Só Poderei Executar O Comando Se Fot Adm`,
login: `Olá @"${pushname}" não achei seu registo digite:"${prefix}registro"`,
grupo: `Comando Privado, Somente Em Grupos`,
semnull: `Digite "${prefixo + command}" "1" ou "0"`,
ativo: `Olá "${pushname}" A Função "${command}" Está Ativa Com Sucesso`,
desativo:`Olá "${pushname}" A Função "${command}" Está Desativada Com sucesso`,
jaatv: `A Função Ja Foi Ativada`,
jadstv: `A Função Ja Esta desativada`,
dono: `Só o meu criador pode Usar Esse comando`,
toy: `Olá "${pushname}" Buscando Sua Ficha De ${prefixo + command}`
}

//MENSAGENS NO CONSOLE DO TERMUX
if(isGroup && isCmd) {
//if(isFiltered(sender)) return enviar(`*Não Fique flodando...*`)
addFilter(sender)}
if (isGroup && isCmd) console.log(`
${color(`╭──────────────────────────────`,`white`)}
${color(`│Local:`,`blue`)} Mensagem em grupo
${color(`│Comando:`,`white`)} ${comando}
${color(`│Número:`,`blue`)} ${sender.split("@")[0]}
${color(`│Grupo:`,`blue`)} ${groupName}
${color(`│Nome:`,`blue`)} ${pushname}
${color(`│Criador Do Bot:`,`blue`)} Theusϟ.mp?
${color(`╰──────────────────────────────`,`white`)}
`)
if (isGroup && !isCmd) console.log(`
${color(`╭──────────────────────────────`,`white`)}
${color(`│Local:`,`blue`)} Mensagem em grupo
${color(`│Comando:`,`blue`)} Não
${color(`│Número:`,`blue`)} ${sender.split("@")[0]}
${color(`│Grupo:`,`blue`)} ${groupName}
${color(`│Nome:`,`blue`)} ${pushname}
${color(`│Criador Do Bot:`,`blue`)} Theusϟ.mp?
${color(`╰──────────────────────────────`,`white`)}
`)

if (!isGroup && isCmd) console.log(`
${color(`╭──────────────────────────────`,`white`)}
${color(`│Local:`,`cyan`)} Mensagem no pv
${color(`│Comando:`,`white`)} ${comando}
${color(`│Número:`,`cyan`)} ${sender.split("@")[0]}
${color(`│Grupo:`,`cyan`)} Não
${color(`│Nome:`,`cyan`)} ${pushname}
${color(`│Criador Do Bot:`,`cyan`)} Theusϟ.mp?
${color(`╰──────────────────────────────`,`white`)}
`)

if (!isGroup && !isCmd) console.log(`
${color(`╭──────────────────────────────`,`white`)}
${color(`│Local:`,`cyan`)} Mensagem no pv
${color(`│Comando:`,`cyan`)} Não
${color(`│Número:`,`cyan`)} ${sender.split("@")[0]}
${color(`│Grupo:`,`cyan`)} Não
${color(`│Nome:`,`cyan`)} ${pushname}
${color(`│Criador Do Bot:`,`cyan`)} Theusϟ.mp?
${color(`╰──────────────────────────────`,`white`)}
`)

const enviargif = (videoDir, caption) => {
theus.sendMessage(from, {
video: fs.readFileSync(videoDir),
caption: caption,
gifPlayback: true
})
}

const enviarimg = (imageDir, caption) => {
theus.sendMessage(from, {
image: fs.readFileSync(imageDir),
caption: caption
})
}

const enviarfig = async (figu, tag) => {
bla = fs.readFileSync(figu)
theus.sendMessage(from, {sticker: bla}, {quoted: info})
}

const sendBimg = async (id, img1, text1, desc1, but = [], vr) => {
buttonMessage = {
image: {url: img1},
caption: text1,
footerText: desc1,
buttons: but,
headerType: 4
}
theus.sendMessage(id, buttonMessage, {quoted: vr})
}

const sendBvidT = async (id, img1, text1, desc1, but = [], vr) => {
templateMessage = {
video: {url: img1},
gifPlayback: true,
caption: text1,
footer: desc1,
templateButtons: but,
}
theus.sendMessage(id, templateMessage, {quoted: vr})
}

const sendBimgT = async (id, img1, text1, desc1, but = [], vr) => {
templateMessage = {
image: {url: img1},
caption: text1,
footer: desc1,
templateButtons: but,
}
theus.sendMessage(id, templateMessage, {quoted: vr})
}

const enviarImgB = async (id, img1, text1, desc1, but = [], vr) => {
buttonMessage = {
image: {url: img1},
caption: text1,
footer: desc1,
buttons: but,
headerType: 4
}
theus.sendMessage(id, buttonMessage, {quoted: vr})
}

const enviartextB = async (id, text1, desc1, but = [], vr) => {
buttonMessage = {
text: text1,
buttons: but,
footer: desc1,
headerType: 4
}
theus.sendMessage(id, buttonMessage, {quoted: vr})
}

if (!isCmd && info.key.fromMe) return

 // TODA CASE QUE FOR COLOCAR COLOQUE EM BAIXO DESSE SWITCH
switch (mopi) {
















/////////////////////TEST\\\\\\\\\\\\\\\\\\\\\\\


//REGISTROOO   >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<
case 'registro':
theus.sendMessage(from, { react: { text: `🤌`, key: info.key }})               
sendBimgT(from, `${logo2}`, `Olá ${pushname} Você Deseja Fazer Login No ${NomeBot} Bot, Caso Queira Pressione Fazer Login Abaixo.`, "BOT-MoPi", [
{index: 1, urlButton: {displayText: 'Numero Do Criador', url: 'https://wa.me/554799544862?text=Oi'}},
{index: 5, quickReplyButton: {displayText: 'Fazer Login', id: `${prefix}login`}}], selocont)
break

//FAÇA LOGIN, FICA SALVO NA PASTA REGISTROS >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<
case 'login':
registros.push(sender)
fs.writeFileSync('./database/funções/usuarios/registros.json',JSON.stringify(registros))
enviar('Calma Ae Amigão Ja Irei Efetuar Seu Login!')
await delay(10000)
enviar(`
 ╭──────────────
 │${tempo} 
 │Login Feito Com Sucesso!
 │Bot: ${nomeBot}
 │Nome: ${pushname} 
 │Número: wa.me/${sender.split('@')[0]} 
 │Celular: ${info.key.id.length > 21 ? 'Android📱' : info.key.id.substring(0, 2) == '3A' ? 'IOS 😑' : 'WhatsApp web 😐'} 
 │Horário: ${time2} 
 │Data: ${data} 
 ╰──────────────`)
break



  // >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<
 // MENUSS
       
// MENU COM BOTÃO 
case 'menu2':
if (!isRegistro) return enviar(resposta.login)
if (budy.includes(`menu`) || (budy.includes(`Menu`))){
}
sendBimgT(from, `${logo2}`, menu(pushname, sender, NomeBot, patt, emoji, numeroDono, nomeDono, selocont, prefixo), "BOT-MoPi", [
{index: 1, urlButton: {displayText: 'Numero Do Criador', url: 'https://wa.me/554799544862'}},
//{index: 5, quickReplyButton: {displayText: 'Forca', id: `${prefix}jogodaforca`}},
//{index: 7, quickReplyButton: {displayText: 'Cassino', id: `${prefix}cassino`}},
{index: 4, quickReplyButton: {displayText: 'Ping', id: `${prefix}ping`}}], selo2)
break
//MENU NOVO
case 'menu':
if (!isRegistro) return enviar(resposta.login)
sendBimg(from, `${logo2}`, fox(prefixo, nomeBot, patt, emoji, nomeDono, pushname, sender), "MoPi", [
{buttonId: `${prefixo}dono`, buttonText: {displayText: `Dono`}, type: 1}, {buttonId: `${prefix}ping`, buttonText: {displayText: `ping`}, type: 1}, {buttonId: `${prefix}level`, buttonText: {displayText: `Level`}, type: 1}], selo1)
break


//FIM MENU >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<

//LEVEL

// ATIVAR FUNÇÃO DE LEVEL EM GRUPOS
case 'leveling':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só Funciona Em Grupo')
if (!isGroupAdmins) return enviar('Você precisa ser adm')
if (args.length < 1) return enviar('Ative pressione 1, Desativar pressione 0')
if (Number(args[0]) === 1) {
if (isLevelingOn) return enviar('*O recurso de nível já estava ativo antes*')
leveling.push(from)
enviar(resposta.ativo)
fs.writeFileSync('./database/funções/usuarios/leveling.json', JSON.stringify(leveling))
} else if (Number(args[0]) === 0) {
if (!isLevelingOn) return enviar(`O recurso de level já está Desativado neste grupo.`)
leveling.splice(from, 1)
fs.writeFileSync('./database/funções/usuarios/leveling.json', JSON.stringify(leveling))
enviar(enviar.desativo)
} else {
enviar('Coloque 1 Para Ativar e 0 Para Desativar')
}
break
// CASE DE LEVEL
case 'level':
if (!isRegistro) return enviar(resposta.login)
const getLevel = getLevelingLevel(sender)
sendBimg(from, `${level}`, `
╭───────────────
│Nome: ${pushname}
│Numero: ${sender.split("@")[0]}
│Patente: ${patt} 
│Level: ${getLevel} 
│Xp: ${getLevelingXp(sender)}
╰───────────────
`, "MoPi-BOT", 
[
{buttonId: `${prefixo}helplevel`, buttonText: {displayText: `Como Faço Pra Subir?`}, type: 1}], selo2)
break
case 'helplevel':
if (!isRegistro) return enviar(resposta.login)
enviar(`
 ╭──────────────
 │ ${tempo}
 │ 
 │Olá @${pushname} Bom Basicamente
 │Terás Que ir Minerando, Ou Seja Ir Interagindo
 │Com o Bot, Seja Com Brincadeiras, Jogos Etc.
 │O Dono Do Bot Também Pode Lhe Dar Xp Por 
 │Atividade No Grupo. Bom Uso Do Bot.
 │
 │Número: wa.me/${sender.split('@')[0]} 
 │Usuário: @${pushname}
 │Data:${data} 
 ╰──────────────`)
break


case 'ganharlevel':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
if (!isGroupAdmins) return enviar('Você precisa ser adm')

if (!isRegistro) return enviar(resposta.login)
addLevelingLevel(sender, 5000)
enviar("Olá chefe, foi adicionado 5000 mil Level para você 🙂")
break

case 'ganharxp':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
if (!isGroupAdmins) return enviar('Você precisa ser adm')

if (!isRegistro) return enviar(resposta.login)
addLevelingXp(sender, 5000)
enviar("Foi adicionado 5000 mil de XP para você 🙂")
break
// FIM LEVEL

// GRUPOS >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<

// GRUPOS
case 'enquete':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
if (!isGroupAdmins) return enviar('Você precisa ser adm')

if (!isRegistro) return enviar(resposta.login)
enquete = generateWAMessageFromContent(from, proto.Message.fromObject({
pollCreationMessage: {
options: [
{ optionName: 'NÃO' },
{ optionName: 'TALVEZ SIM'},
{ optionName: 'SIM'}, 
{ optionName: 'TALVEZ NÃO'}
],
name: `${q}`,
selectableOptionsCount: 0
}
}), { userJid: from })
await theus.relayMessage(from, enquete.message, { messageId: enquete.key.id})
break

case 'ping':
if (!isRegistro) return enviar(resposta.login)
timestampe = speed();
latensie = speed() - timestampe
uptime = process.uptime()
hora1 = moment.tz('America/Sao_Paulo').format('HH:mm:ss');
sendBimgT(from, `${ping}`, `
╭───────────────────
│Olá ${pushname} ${tempo}
│Velocidade: ${latensie.toFixed(4)}
│${!isGroup ? `Usuario: ${pushname}` :  `Grupo: ${groupName}`}
│Tempo Ativo: ${runtime(uptime)}
│Nome Do Bot: ${nomeBot}
╰───────────────────
`, "MoPi-BOT", [
{index: 1, urlButton: {displayText: 'Dono', url: 'https://wa.me/554799544862?text=Oi'}},
{index: 2, quickReplyButton: {displayText: 'Denovo', id: `${prefix}ping`}},], selo2)
break

case 'reagir':
if (!isRegistro) return enviar(resposta.login)
{
theus.sendMessage(from, { react: { text: `${reagir}`, key: info.key }})               
}
break

// FUNÇÕES DO DONO >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<
case 'serpremium':
case 'serprem':  
if (!isOwner) return enviar(resposta.dono)
if (!isRegistro) return enviar(resposta.login)
premium.push(`${numeroDono}@s.whatsapp.net`)
fs.writeFileSync('./database/funções/usuarios/premium.json', JSON.stringify(premium))
enviar(`Pronto ${numeroDono} você foi adicionado na lista premium.`)
break

case 'addpremium':
if (!isRegistro) return enviar(resposta.login)
if (!isOwner) return enviar(resposta.dono)
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return 
if (!budy.includes("@55")) {
mentioned = info.message.extendedTextMessage.contextInfo.participant 
bla = premium.includes(mentioned)
if(bla) return enviar("*Este número já está incluso..*")  
premium.push(`${mentioned}`)
fs.writeFileSync('./database/funções/usuarios/premium.json', JSON.stringify(premium))
theus.sendMessage(from, {text: `👑@${mentioned.split("@")[0]} foi adicionado à lista de usuários premium com sucesso👑`}, {quoted: info})  
} else { 
mentioned = args.join(" ").replace("@", "") + "@s.whatsapp.net"
bla = premium.includes(mentioned)
if(bla) return enviar("*Este número já está incluso..*")  
premium.push(`${mentioned}`)
fs.writeFileSync('./database/funções/usuarios/premium.json', JSON.stringify(premium))
tedtp = args.join(" ").replace("@", "")
theus.sendMessage(from, {text: `👑@${tedtp} foi adicionado à lista de usuários premium com sucesso👑`, mentions: [mentioned]}, {quoted: info})
}
break 

case 'delpremium':
if (!isOwner) return enviar(resposta.dono)
if (!isRegistro) return enviar(resposta.login)
if (!budy.includes("@55")) {
num = info.message.extendedTextMessage.contextInfo.participant
bla = premium.includes(num)
if(!bla) return enviar("*Este número não está incluso na lista premium..*")  
pesquisar = num
processo = premium.indexOf(pesquisar)
while(processo >= 0){
premium.splice(processo, 1)
processo = premium.indexOf(pesquisar)
}
fs.writeFileSync('./database/funções/usuarios/premium.json', JSON.stringify(premium))
theus.sendMessage(from, {text: ` ${num.split("@")[0]} foi tirado da lista premium com sucesso..`}, {quoted: info})
} else {
mentioned = args.join(" ").replace("@", "") + "@s.whatsapp.net"
bla = premium.includes(mentioned)
if(!bla) return enviar("*Este número não está incluso na lista premium..*")  
pesquisar = mentioned
processo = premium.indexOf(pesquisar)
while(processo >= 0){
premium.splice(processo, 1)
processo = premium.indexOf(pesquisar)
}
fs.writeFileSync('./database/funções/usuarios/premium.json', JSON.stringify(premium))
theus.sendMessage(from, {text: ` @${mentioned.split("@")[0]} foi tirado da lista premium com sucesso..`}, {quoted: info})
}
break


case 'premiumlist':
if (!isRegistro) return enviar(resposta.login)
tkks = '╭─ Lista De Premium\n'
for (let V of premium) {
tkks += `│ ->${V.split('@')[0]}\n`
}
tkks += `│ Total : ${premium.length}\n╰──── *${NomeBot}* ───`
enviar(tkks.trim())
break
case "dono":
theus.sendMessage(from, {text: "https://wa.me/554799544862"}, { quoted: selovid})  
await sleep(2000)
theus.sendMessage(from, {text: "Theusϟ.mp? o nome dele, precisar de algo so chamar ae",}, { quoted: selovid})  
break
case 'y':
theus.sendMessage(from, {text:  '『❗』𝙴𝚗𝚟𝚒𝚊𝚗𝚍𝚘...'}, {quoted: info})
theus.sendMessage(sender, {displayname: "Jeff", vcard: vcard}, contact, {quoted: info})
break
//FIM DONO

// DO BOT >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<
case 'reiniciar':
if (!isOwner) return enviar(resposta.dono)
enviar(`Reiniciando...`)
await sleep(2000)
process.exit()
break

//⚠️CASES ALEATORIAS DE TESTES⚠️
///-------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « ---------------------------- » «» « --------------
case 'menu': {
data = fs.readFileSync('./database/files/fotos/selo.jpg');
let buttons = [
{buttonId: `${prefix}menu2`, buttonText: {displayText: '⏅ 𝐌 𝐄 𝐍 𝐔 𝟐⏅'}, type: 1}, 
{buttonId: `${prefix}ping`, buttonText: {displayText: '⏅ 𝐏 𝐈 𝐍 𝐆 ⏅'}, type: 1}]
let thumbInfo = `${menuclaro(namebot, nameWoner, ownerNumber, emoji, V, prefix, tempo, pushname)}`;
blabla = await getBuffer(`https://telegra.ph/file/0e2989e6947b464fa66b8.jpg`);
buttonMessage = {image: imagem, caption: `${thumbInfo}`, 
footer: `${menuescuro(emoji, prefix, tempo, pushname)}`
, buttons: buttons, headerType: 4}
theus.sendMessage(m.chat, buttonMessage,{quoted: selo})
}
case "quoted":
enviar(replys_mopi), { quoted: selo} 
await sleep(2000)
theus.sendMessage(from, {text: "https://4br.me/selos"}, { quoted: selogp})  
break
case "test":
theus.sendMessage(from, {text: "texto com selo"}, { quoted: seloOn})  
await sleep(3000)
theus.sendMessage(from, {text: "texto sem selo"}, { quoted: seloOff})  
break
case 'report':
if (!text) return enviar( 'Oque Deseja Reportar Ao Meu Dono?')
const bug = `${q}`
 if (args.length > 300) return theus.sendMessage(from, 'Máximo 300 caracteres', msgType.text, {quoted: info})
var nomor = info.participant
teks1 = `╭Sugestão + Reporte\n -> De: ${pushname}\n -> Numero: @${sender.split("@s.whatsapp.net")[0]}\n╰━━━━━── • ──━━━━━\n > 𝖲𝗎𝗀𝖾𝗌𝗍𝖺̃𝗈:\n${bug}`
var options = {text: teks1, contextInfo: {mentionedJid: [sender]},}
theus.sendMessage(`${numeroDono}@s.whatsapp.net`, options, text)
enviar("Mensagem enviada ao meu dono; Spam = block + ban.")
break

/*case 'lista': {
const sections = [
				{
					title: "Sessão 1",
					rows: [
						{ title: 'Opção 1', rowId: `${prefix}dono`},
						{ title: "Opção 2", rowId: "id2", description: "Descrição " }
					]
				},
				{
					title: "Sessão 2",
					rows: [
						{ title: "Opção 3", rowId: "id3" },
						{ title: "Opção 4", rowId: "id4", description: "Descrição" }
					]
				},
			]

			const listMessage = {
				text: "Texto da lista",
				footer: "BOT-MoPi",
				title: "Título da lista",
				buttonText: "Botão da lista",
				sections
			}
theus.sendMessage(from, listMessage)
}
break*/
// CASE DE FIGURINHAS ETC
/*case 'figurinha': case 's': case 'stickergifp': case 'figura': case 'f': case 'figu': case 'st': case 'stk': case 'fgif':
if (!isRegistro) return enviar(resposta.login)
{
(async function () {
var legenda = q ? q?.split("/")[0] : ` Solicitado Por:
 Bot:
 Dono:`
var autor = q ? q?.split("/")[1] : q?.split("/")[0] ? '' : `${pushname}
${NomeBot}
${NomeDono}`
if (isMedia && !info.message.videoMessage || isQuotedImage) {
var encmedia = isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage
rane = getRandom('.'+await getExtension(encmedia.mimetype))
buffimg = await getFileBuffer(encmedia, 'image')
fs.writeFileSync(rane, buffimg)
rano = getRandom('.webp')
exec(`ffmpeg -i ${rane} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 800:800 ${rano}`, (err) => {
fs.unlinkSync(rane)
// "android-app-store-link": "https://play.google.com/store/search?q=%2B55%2094%209147-2796%20%F0%9F%94%A5%F0%9F%94%A5%F0%9F%94%A5%F0%9F%94%A5%F0%9F%94%A5&c=apps",
var json = {
"sticker-pack-name": legenda,
"sticker-pack-publisher": autor
}
var exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
var jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
var exif = Buffer.concat([exifAttr, jsonBuff])
exif.writeUIntLE(jsonBuff.length, 14, 4)
let nomemeta = Math.floor(Math.random() * (99999 - 11111 + 1) + 11111)+".temp.exif"
fs.writeFileSync(`./${nomemeta}`, exif) 
exec(`webpmux -set exif ${nomemeta} ${rano} -o ${rano}`, () => {
theus.sendMessage(from, {sticker: fs.readFileSync(rano)}, {quoted: info})
fs.unlinkSync(nomemeta)
fs.unlinkSync(rano)
})
})
} else if (isMedia && info.message.videoMessage.seconds < 11 || isQuotedVideo && info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 35) {
var encmedia = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage
rane = getRandom('.'+await getExtension(encmedia.mimetype))
buffimg = await getFileBuffer(encmedia, 'video')
fs.writeFileSync(rane, buffimg)
rano = getRandom('.webp')
await ffmpeg(`./${rane}`)
.inputFormat(rane.split('.')[1])
exec(`ffmpeg -i ${rane} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 200:200 ${rano}`, (err) => {
fs.unlinkSync(rane)
let json = {
"sticker-pack-name": legenda,
"sticker-pack-publisher": autor
}
let exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
let jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
let exif = Buffer.concat([exifAttr, jsonBuff])
exif.writeUIntLE(jsonBuff.length, 14, 4)
let nomemeta = "temp.exif"
fs.writeFileSync(`./${nomemeta}`, exif) 
exec(`webpmux -set exif ${nomemeta} ${rano} -o ${rano}`, () => {
theus.sendMessage(from, {sticker: fs.readFileSync(rano)}, {quoted: info})
fs.unlinkSync(nomemeta)
fs.unlinkSync(rano)
})
})
} else {
enviar(`Você precisa enviar ou marcar uma imagem ou vídeo com no máximo 10 segundos`)
}
})().catch(e => {
console.log(e)
enviar("Hmm deu erro")
try {
if (fs.existsSync("temp.exif")) fs.unlinkSync("temp.exif");
if (fs.existsSync(rano)) fs.unlinkSync(rano);
if (fs.existsSync(media)) fs.unlinkSync(media);
} catch {}
})
}
break*/

// FIGURINHAS >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<
case 'figurinha': case 's': case 'stickergifp': case 'figura': case 'f': case 'figu': case 'st': case 'stk': case 'fgif':
if (!isRegistro) return enviar(resposta.login)
if (!isCmd) return enviar(replys_mopi)
{
(async function () {
var legenda = q ? q?.split("/")[0] : `┈┈─╼⊳⊰ Solicitado Por:
┈┈─╼⊳⊰ Bot:
┈┈─╼⊳⊰ Dono:`
var autor = q ? q?.split("/")[1] : q?.split("/")[0] ? '' : `${pushname}
${NomeBot}
${NomeDono}`
if (isMedia && !info.message.videoMessage || isQuotedImage) {
var encmedia = isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage
rane = getRandom('.'+await getExtension(encmedia.mimetype))
buffimg = await getFileBuffer(encmedia, 'image')
fs.writeFileSync(rane, buffimg)
rano = getRandom('.webp')
exec(`ffmpeg -i ${rane} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 800:800 ${rano}`, (err) => {
fs.unlinkSync(rane)
// "android-app-store-link": "https://play.google.com/store/search?q=%2B55%2094%209147-2796%20%F0%9F%94%A5%F0%9F%94%A5%F0%9F%94%A5%F0%9F%94%A5%F0%9F%94%A5&c=apps",
var json = {
"sticker-pack-name": legenda,
"sticker-pack-publisher": autor
}
var exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
var jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
var exif = Buffer.concat([exifAttr, jsonBuff])
exif.writeUIntLE(jsonBuff.length, 14, 4)
let nomemeta = Math.floor(Math.random() * (99999 - 11111 + 1) + 11111)+".temp.exif"
fs.writeFileSync(`./${nomemeta}`, exif) 
exec(`webpmux -set exif ${nomemeta} ${rano} -o ${rano}`, () => {
theus.sendMessage(from, {sticker: fs.readFileSync(rano)}, {quoted: info})
fs.unlinkSync(nomemeta)
fs.unlinkSync(rano)
})
})
} else if (isMedia && info.message.videoMessage.seconds < 11 || isQuotedVideo && info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage.seconds < 35) {
var encmedia = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage
rane = getRandom('.'+await getExtension(encmedia.mimetype))
buffimg = await getFileBuffer(encmedia, 'video')
fs.writeFileSync(rane, buffimg)
rano = getRandom('.webp')
await ffmpeg(`./${rane}`)
.inputFormat(rane.split('.')[1])
exec(`ffmpeg -i ${rane} -vcodec libwebp -filter:v fps=fps=15 -lossless 1 -loop 0 -preset default -an -vsync 0 -s 200:200 ${rano}`, (err) => {
fs.unlinkSync(rane)
let json = {
"sticker-pack-name": legenda,
"sticker-pack-publisher": autor
}
let exifAttr = Buffer.from([0x49, 0x49, 0x2A, 0x00, 0x08, 0x00, 0x00, 0x00, 0x01, 0x00, 0x41, 0x57, 0x07, 0x00, 0x00, 0x00, 0x00, 0x00, 0x16, 0x00, 0x00, 0x00])
let jsonBuff = Buffer.from(JSON.stringify(json), "utf-8")
let exif = Buffer.concat([exifAttr, jsonBuff])
exif.writeUIntLE(jsonBuff.length, 14, 4)
let nomemeta = "temp.exif"
fs.writeFileSync(`./${nomemeta}`, exif) 
exec(`webpmux -set exif ${nomemeta} ${rano} -o ${rano}`, () => {
theus.sendMessage(from, {sticker: fs.readFileSync(rano)}, {quoted: info})
fs.unlinkSync(nomemeta)
fs.unlinkSync(rano)
})
})
} else {
enviar(`Você precisa enviar ou marcar uma imagem ou vídeo com no máximo 10 segundos`)
}
})().catch(e => {
console.log(e)
enviar("Hmm deu erro")
try {
if (fs.existsSync("temp.exif")) fs.unlinkSync("temp.exif");
if (fs.existsSync(rano)) fs.unlinkSync(rano);
if (fs.existsSync(media)) fs.unlinkSync(media);
} catch {}
})
}
break

// CASES DE GRUPO 2.0 >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<
case 'entra': case 'entrar': case 'entrargp': case 'convite':  {
if (!isRegistro) return enviar(resposta.login)
if (!isOwner) return enviar(resposta.dono)
if (!text) return enviar( 'Preciso do Link Do Grupo Caro Amigo!')
if (!isUrl(args[0]) && !args[0].includes('whatsapp.com')) return enviar( 'Link Invalido ou não é um grupo de Whatsapp!')
let result = args[0].split('https://chat.whatsapp.com/')[1]
await theus.groupAcceptInvite(result)
enviar('Pronto O Bot Entrou Com Sucesso!')
}
break
case 'sairgp': case 'sair':
if (!isRegistro) return enviar(resposta.login)
if (!isOwner) return enviar(resposta.dono)
enviar("ok... Perdão Se Eu Não Pude Ajudar Você😕")
await delay(1000)
try {
theus.groupLeave(from)

} catch(e) {
console.log(e)
enviar("erro")
}
break
case 'mudarlink':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só pode ser utilizado em Grupo')
if (!isGroupAdmins) return enviar('Você precisa ser ADM')
if (!isBotGroupAdmins) return enviar('O bot Precisa ser ADM')
try {
await theus.groupRevokeInvite(from)
enviar("Link de convite resetado com sucesso ✓ ")
} catch(e) {
console.log(e)
enviar(resposta.erro)
}
break
//=
case 'repetir': //ERRO
if (!isRegistro) return enviar(resposta.login)
rsp = q.replace(new RegExp("[()+-/ +a/b/c/d/e/fghijklmnopqrstwuvxyz/]", "gi"), "")
enviar(rsp)
break

case 'calculadora': case 'calcular':  case 'calc':
if (!isRegistro) return enviar(resposta.login)
if (!text) return enviar( 'Qual o Calculo Que Deseja Fazer?')
rsp = q.replace("x", "*").replace('"', ":").replace(new RegExp("[()abcdefghijklmnopqrstwuvxyz]", "gi"), "").replace("÷", "/")
console.log('[', color('EVAL', 'silver'),']', color(moment(info.messageTimestamp * 1000).format('DD/MM HH:mm:ss'), 'yellow'), color(rsp))
return enviar(JSON.stringify(eval(`${rsp}`,null,'\t')))
break 

case 'nomegp':
if (!isRegistro) return enviar(resposta.login)
if (!text) return enviar( 'Qual Nome Deseja Colocar?')
blat = args.join(" ")
theus.groupUpdateSubject(from, `${blat}`)
theus.sendMessage(from, {text: 'Sucesso, alterou o nome do grupo'}, {quoted: info})
break

case 'descgp': case 'descriçãogp':  
if (!isRegistro) return enviar(resposta.login)
if (!text) return enviar( 'Digite Oque Queres Na Descrição!')
touc = args.join(" ")
theus.groupUpdateDescription(from, `${touc}`)
theus.sendMessage(from, {text: 'Sucesso, alterou a descrição do grupo'}, {quoted: info})
break

case 'setfotogp': case 'fotogp':  
addFilter(from)
if (!isGroup) return enviar('Só pode ser utilizado em Grupo')
if (!isGroupAdmins) return enviar('Você precisa ser ADM')
if (!isBotGroupAdmins) return enviar('O bot Precisa ser ADM')
if (!isQuotedImage) return enviar(`Use: ${prefix + command} e Marque Uma Imagem!`)
ftgp = isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage
rane = getRandom('.'+await getExtension(ftgp.mimetype))
buffimg = await getFileBuffer(ftgp, 'image')
fs.writeFileSync(rane, buffimg)
medipp = rane 
await theus.updateProfilePicture(from, {url: medipp})
enviar(`Foto do grupo alterada com sucesso`) 
break

case 'linkgp': case 'linkgroup':
if (!isBotGroupAdmins) return enviar('O bot Precisa ser ADM')
linkgc = await theus.groupInviteCode(from)
enviar('https://chat.whatsapp.com/'+linkgc)
break

case 'totag': case 'cita': case 'hidetag':
if(!isGroup) return enviar('Este comando só deve ser utilizado em Grupo.')
if(!isGroupAdmins) return enviar('Você precisa ser ADM pra utilizar este comando')
membros = (groupId, membros1) => {
array = []
for (let i = 0; i < membros1.length; i++) {
array.push(membros1[i].id)
}
return array
}
var yd = membros(from, groupMembers)
if((isMedia && !info.message.videoMessage || isQuotedSticker) && args.length == 0) {
media = isQuotedSticker ? info.message.extendedTextMessage.contextInfo.quotedMessage.stickerMessage : info.message.stickerMessage
rane = getRandom('.'+await getExtension(media.mimetype))
img = await getFileBuffer(media, 'sticker')
fs.writeFileSync(rane,img)
fig = fs.readFileSync(rane)
var options = {
sticker: fig,  
mentions: yd
}
theus.sendMessage(from, options)
} else if ((isMedia && !info.message.videoMessage || isQuotedImage) && args.length == 0) {
media = isQuotedImage ? info.message.extendedTextMessage.contextInfo.quotedMessage.imageMessage : info.message.imageMessage
rane = getRandom('.'+await getExtension(media.mimetype))
img = await getFileBuffer(media, 'image')
fs.writeFileSync(rane,img)
buff = fs.readFileSync(rane)
theus.sendMessage(from, {image: buff, mentions: yd}, {quoted: info})
} else if ((isMedia && !info.message.videoMessage || isQuotedVideo) && args.length == 0) {
media = isQuotedVideo ? info.message.extendedTextMessage.contextInfo.quotedMessage.videoMessage : info.message.videoMessage
rane = getRandom('.'+await getExtension(media.mimetype))
vid = await getFileBuffer(media, 'video')
fs.writeFileSync(rane,vid)
buff = fs.readFileSync(rane)
theus.sendMessage(from, {video: buff, mimetype: 'video/mp4',mentions: yd}, {quoted: info})
} else if ((isMedia && !info.message.videoMessage || isQuotedAudio) && args.length == 0) {
media = isQuotedAudio ? info.message.extendedTextMessage.contextInfo.quotedMessage.audioMessage : info.message.audioMessage
rane = getRandom('.'+await getExtension(media.mimetype))
aud = await getFileBuffer(media, 'audio')
fs.writeFileSync(rane,aud)
buff = fs.readFileSync(rane)
theus.sendMessage(from, {audio: buff, mimetype: 'audio/mp4', ptt:true,mentions: yd}, {quoted: info})
} else if ((isMedia && !info.message.videoMessage || isQuotedDocument) && args.length == 0) {
media = isQuotedDocument ? info.message.extendedTextMessage.contextInfo.quotedMessage.documentMessage : info.message.documentMessage
rane = getRandom('.'+await getExtension(media.mimetype))
doc = await getFileBuffer(media, 'document')
fs.writeFileSync(rane,doc)
buff = fs.readFileSync(rane)
theus.sendMessage(from, {document: buff, mimetype : 'text/plain',mentions: yd},{quoted: info})
} else if(budy){
if(q.length < 1) return enviar('Citar oq?')
theus.sendMessage(from, {text: body.slice(command.length + 2), mentions: yd})
} else {
enviar(`Responder imagem/documento/gif/adesivo/áudio/vídeo com legenda ${prefix + command}`)
}
break

case 'marcar':
try {
if (!isGroup) return enviar('Este comando só deve ser utilizado em Grupo.')
if (!isGroupAdmins) return enviar('Você precisa ser ADM pra utilizar este comando')  
members_id = []
teks = (args.length > 1) ? body.slice(10).trim() : ''
teks += '\n\n'
for (let mem of groupMembers) {
teks += `> @${mem.id.split('@')[0]}\n`
members_id.push(mem.id)
}
theus.sendMessage(from, {text: teks}, {quoted: info})
} catch {
enviar('ERROR!!')
}
break

case 'rebaixar': case 'demote':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
if (!isGroupAdmins) return enviar('Você precisa ser adm')
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return enviar('Marque ou responda a mensagem de quem você quer tirar de admin')
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid[0] ? info.message.extendedTextMessage.contextInfo.mentionedJid[0] : info.message.extendedTextMessage.contextInfo.participant
let responsepm = await theus.groupParticipantsUpdate(from, [mentioned], 'demote')
if (responsepm[0].status === "406") theus.sendMessage(from, {text: `@${mentioned.split("@")[0]} criou esse grupo e não pode ser removido(a) da lista de admins.️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responsepm[0].status === "200") theus.sendMessage(from, {text: `@${mentioned.split("@")[0]} Foi Removido Da Lista De Adms️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responsepm[0].status === "404") theus.sendMessage(from, {text: `@${mentioned.split("@")[0]} não Está no grupo️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else theus.sendMessage(from, {text: `Parece que deu erro️`, mentions: [sender], contextInfo:{forwardingScore:999, isForwarded:true}})
break

case 'promover': case 'promote':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
if (!isGroupAdmins) return enviar('Você precisa ser adm')
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return enviar('Marque ou responda a mensagem de quem você quer promover')
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid[0] ? info.message.extendedTextMessage.contextInfo.mentionedJid[0] : info.message.extendedTextMessage.contextInfo.participant
let responsedm = await theus.groupParticipantsUpdate(from, [mentioned], 'promote')
if (responsedm[0].status === "200") theus.sendMessage(from, {text: `@${mentioned.split("@")[0]} Foi Promovido a Adm Com Sucesso`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responsedm[0].status === "404") theus.sendMessage(from, {text: `@${mentioned.split("@")[0]} não está no grupo️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else theus.sendMessage(from, {text: `Parece que deu erro️`, mentions: [sender], contextInfo:{forwardingScore:999, isForwarded:true}})
break

case 'ban': case 'kick':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
if (!isGroupAdmins) return enviar('Você precisa ser adm')
{
if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return enviar('Responda a mensagem ou marque a pessoa que você quer remover do grupo')
if(info.message.extendedTextMessage.contextInfo.participant !== null && info.message.extendedTextMessage.contextInfo.participant != undefined && info.message.extendedTextMessage.contextInfo.participant !== "") {
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid[0] ? info.message.extendedTextMessage.contextInfo.mentionedJid[0] : info.message.extendedTextMessage.contextInfo.participant
let responseb = await theus.groupParticipantsUpdate(from, [mentioned], 'remove')
if (responseb[0].status === "200") theus.sendMessage(from, {text: `@${mentioned.split("@")[0]} foi removido do grupo com sucesso.️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responseb[0].status === "406") theus.sendMessage(from, {text: `@${mentioned.split("@")[0]} criou esse grupo e não pode ser removido(a) do grupo️`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responseb[0].status === "404") theus.sendMessage(from, {text: `@${mentioned.split("@")[0]} já foi removido(a) ou saiu do grupo`, mentions: [mentioned, sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else theus.sendMessage(from, {text: `Hmm parece que deu erro️`, mentions: [sender], contextInfo:{forwardingScore:999, isForwarded:true}})
} else if (info.message.extendedTextMessage.contextInfo.mentionedJid != null && info.message.extendedTextMessage.contextInfo.mentionedJid != undefined) {
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
if(mentioned.length > 1) {
if(mentioned.length > groupMembers.length || mentioned.length === groupMembers.length || mentioned.length > groupMembers.length - 3) return enviar(`Vai banir todo mundo mesmo?`)
sexocomrato = 0
for (let banned of mentioned) {
await sleep(100)
let responseb2 = await theus.groupParticipantsUpdate(from, [banned], 'remove')
if (responseb2[0].status === "200") sexocomrato = sexocomrato + 1
}
theus.sendMessage(from, {text: `${sexocomrato} participantes removido do grupo`, mentions: [sender], contextInfo:{forwardingScore:999, isForwarded:true}})
} else {
let responseb3 = await theus.groupParticipantsUpdate(from, [mentioned[0]], 'remove')
if (responseb3[0].status === "200") theus.sendMessage(from, {text: `@${mentioned[0].split("@")[0]} foi removido do grupo com sucesso.️`, mentions: [mentioned[0], sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responseb3[0].status === "406") theus.sendMessage(from, {text: `@${mentioned[0].split("@")[0]} criou esse grupo e não pode ser removido(a) do grupo️`, mentions: [mentioned[0], sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else if (responseb3[0].status === "404") theus.sendMessage(from, {text: `@${mentioned[0].split("@")[0]} já foi removido(a) ou saiu do grupo`, mentions: [mentioned[0], sender], contextInfo:{forwardingScore:999, isForwarded:true}})
else theus.sendMessage(from, {text: `Hmm parece que deu erro️`, mentions: [sender], contextInfo:{forwardingScore:999, isForwarded:true}})
}
}
}
break

/*case 'add': case 'unkick': case 'reviver':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
if (!isGroupAdmins) return enviar('Você precisa ser adm')
if(!q && info.message.extendedTextMessage === null) return enviar('Marque a mensagem ou coloque o número de quem você quer adicionar no grupo')
try {
useradd = `${args.join(" ").replace(/\D/g,'')}` ? `${args.join(" ").replace(/\D/g,'')}` : info.message.extendedTextMessage.contextInfo.participant
let id = `${useradd.replace(/\D/g,'')}`
if(!id) return enviar(`Número inválido`)
let [result] = await theus.onWhatsApp(id)
if(!result) return enviar(`Esse número não está registrado no WhatsApp`)
let response = await theus.groupParticipantsUpdate(from, [result.jid], "add")
if(response[0].status == "409") {
theus.sendMessage(from, {text: `Ele já está no grupo, como eu vou adicionar?`, mentions: [result.jid, sender]})
} else if(response[0].status == "403") {
theus.sendMessage(from, {text: `Não consegui adicionar o @${result.jid.split("@")[0]} porque ele privou a conta`, mentions: [result.jid, sender]})
} else if(response[0].status == "408") {
theus.sendMessage(from, {text: `Não consegui adicionar o @${result.jid.split("@")[0]} porque ele saiu recentemente do grupo.`, mentions: [result.jid, sender]})
} else if(response[0].status == "401") {
theus.sendMessage(from, {text: `Não consegui adicionar o @${result.jid.split("@")[0]} porque ele bloqueou o bot`, mentions: [result.jid, sender]})
} else if(response[0].status == "200") {
theus.sendMessage(from, {text: `Prontinho fiz o que você pediu`, mentions: [result.jid, sender]})
} else {
enviar("Vish acho que algo deu errado")
}
} catch {
}
break*/

// BRINCADEIRAS EM GRUPO >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<
case 'cassino':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
const soto = [
'🍊 : 🍒 : 🍐',
'🍒 : 🔔 : 🍊',
'🍇 : 🍇 : 🍇',
'🍊 : 🍋 : 🔔',
'🔔 : 🍒 : 🍐',
'🔔 : 🍒 : 🍊',
'🍊 : 🍋 : ??',		
'🍐 : 🍒 : 🍋',
'🍐 : 🍐 : 🍐',
'🍊 : 🍒 : 🍒',
'🔔 : 🔔 : 🍇',
'🍌 : 🍒 : 🔔',
'🍐 : 🔔 : 🔔',
'🍊 : 🍋 : 🍒',
'🍋 : 🍋 : 🍌',
'🔔 : 🔔 : 🍇',
'🔔 : 🍐 : 🍇',
'🔔 : 🔔 : 🔔',
'🍒 : 🍒 : 🍒',
'🍌 : 🍌 : 🍌'
]		  

const somtoy2 = sotoy[Math.floor(Math.random() * sotoy.length)]
if ((somtoy2 == '🥑 : 🥑 : 🥑') ||(somtoy2 == '🍉 : 🍉 : 🍉') ||(somtoy2 == '🍓 : 🍓 : 🍓') ||(somtoy2 == '🍎 : 🍎 : 🍎') ||(somtoy2 == '🍍 : 🍍 : 🍍') ||(somtoy2 == '🥝 : 🥝 : 🥝') ||(somtoy2 == '🍑 : 🍑 : 🍑') ||(somtoy2 == '🥥 : 🥥 : 🥥') ||(somtoy2 == '🍋 : 🍋 : 🍋') ||(somtoy2 == '🍐 : 🍐 : 🍐') ||(somtoy2 == '🍌 : 🍌 : 🍌') ||(somtoy2 == '🍒 : 🍒 : 🍒') ||(somtoy2 == '🔔 : 🔔 : 🔔') ||(somtoy2 == '🍊 : 🍊 : 🍊') ||(somtoy2 == '🍇 : 🍇 : 🍇')) {
var Vitória = "Você ganhou!!!"
} else {
var Vitória = "Você perdeu..."
}
sendBimgT(from, `${meno2}`, `
╭─────────
│   ${somtoy2}
╰─────────

*${Vitória}*

`, "BOT-MoPi", [{index: 1, urlButton: {displayText: 'Criador', url: 'https://wa.me/554799544862?text=Oi'}},
{index: 2, quickReplyButton: {displayText: 'Cassino', id: `${prefix}cassino`}},], selo2)
break

case 'anagrama':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
if (args.length < 1) return enviar('Ative pressionando 1, Desativar pressione 0')
if(!isGroup) return enviar(resposta.grupo)
const anaaleatorio = Math.floor(Math.random() * palavrasANA.length)
if(args.length == 0) return enviar(resposta.semnull)
if (args.join(' ') === '1') {
if(fs.existsSync(`./database/funções/anagrama/anagrama-${from}.json`)) {
let dataAnagrama2 = JSON.parse(fs.readFileSync(`./database/funções/anagrama/anagrama-${from}.json`))
enviar(`o jogo já foi iniciado neste grupo:
palavra: ${dataAnagrama2.embaralhada}
dica: ${dataAnagrama2.dica}
`)} else {
fs.writeFileSync(`./database/funções/anagrama/anagrama-${from}.json`, `${JSON.stringify(palavrasANA[anaaleatorio])}`)
theus.sendMessage(from, {text: `
╭──────────────
│   Descubra A Palavra 
│
│   ANAGRAMA: ${palavrasANA[anaaleatorio].embaralhada}
│
│   DICA: ${palavrasANA[anaaleatorio].dica}
╰──────────────
`})
}
} else if (args.join(' ') ==='0') {
if(!fs.existsSync(`./database/funções/anagrama/anagrama-${from}.json`)) return enviar('não tem como desativar o jogo do anagrama pôs ele não foi ativado')
fs.unlinkSync(`./database/funções/anagrama/anagrama-${from}.json`)
enviar("desativado com sucesso")
}
break

case 'resetforca':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

if(!isPlayForca) return enviar(`*Você não iniciou uma partida, para iniciar dê o comando ${prefix}jogodaforca*`)
pla_pos = allForcaId.indexOf(sender)
forca.splice(pla_pos, 1)
fs.writeFileSync('database/funções/grupos/forca.json', JSON.stringify(forca, null, 2))
enviar(`*Jogo da forca reiniciado com sucesso. Para iniciar outra partida dê o comando ${prefix}jogodaforca*`)
break
case 'forca':
if(!isPlayForca) return enviar(`*Você não iniciou uma partida, para iniciar dê o comando ${prefix}jogodaforca*`)
if(args.length < 1) return enviar(`*Dê o comando mais a letra para advinhar*`)
if(args[0].trim().length < 2) {
    p_pos = allForcaId.indexOf(sender)
    find = forca[p_pos].word.match(args[0].toLowerCase())
    is_correct = false 
    while(find != null) {
res_tmp = forca[p_pos].word.indexOf(args[0].toLowerCase())
forca[p_pos].array_under_word[res_tmp] = args[0].toLowerCase()
forca[p_pos].array_word[res_tmp] = 0
forca[p_pos].word = forca[p_pos].word.replace(args[0].toLowerCase(), 0)
find = forca[p_pos].word.match(args[0].toLowerCase())
is_correct = true
    }
    if(is_correct) {
str_under = ''
for(i=0;i<forca[p_pos].array_under_word.length;++i) str_under += forca[p_pos].array_under_word[i]
attempts = forca[p_pos].attempts
if(str_under == forca[p_pos].word_original) {
enviar(`*Parabéns, Você venceu o jogo!🥳*\n\n${puppet[attempts]}\n\n_*Palavra: ${str_under.split('').join(' ')}*_`)
forca.splice(p_pos, 1)
fs.writeFileSync('database/funções/grupos/forca.json', JSON.stringify(forca, null, 2))
} else {
enviar(`*Você acertou!*\n\n${puppet[attempts]}\n\n_*Palavra: ${str_under.split('').join(' ')}*_\n*Você tem ${attempts} chances*`)
fs.writeFileSync('database/funções/grupos/forca.json', JSON.stringify(forca, null, 2))
}
    } else  {
str_under = ''
for(i=0;i<forca[p_pos].array_under_word.length;++i) str_under += forca[p_pos].array_under_word[i]
forca[p_pos].attempts -= 1
attempts = forca[p_pos].attempts
if(forca[p_pos].attempts <= 0) {
forca.splice(p_pos, 1)
fs.writeFileSync('database/funções/grupos/forca.json', JSON.stringify(forca, null, 2))
enviar(`*Você perdeu o jogo!❌*\n\n${puppet[attempts]}\n\n*Palavra: ${str_under.split('').join(' ')}*\n*Suas chances se esgotaram*`)
} else {
enviar(`*Você errou!❌*\n\n${puppet[attempts]}\n\n*Palavra: ${str_under.split('').join(' ')}*\n*Você tem ${attempts} chances*`)
fs.writeFileSync('database/funções/grupos/forca.json', JSON.stringify(forca, null, 2))
}
    }
} else {
    p_pos = allForcaId.indexOf(sender)
    if(forca[p_pos].word_original == args[0].toLowerCase()) {
attempts = forca[p_pos].attempts
enviar(`*Parabéns, Você venceu o jogo!🥳*\n\n${puppet[attempts]}\n\n_*Palavra: ${forca[p_pos].word_original.split('').join(' ')}*_`)
forca.splice(p_pos, 1)
fs.writeFileSync('database/funções/grupos/forca.json', JSON.stringify(forca, null, 2))
    } else {
str_under = ''
for(i=0;i<forca[p_pos].array_under_word.length;++i) str_under += forca[p_pos].array_under_word[i]
forca[p_pos].attempts -= 1
attempts = forca[p_pos].attempts
if(forca[p_pos].attempts <= 0) {
forca.splice(p_pos, 1)
fs.writeFileSync('database/funções/grupos/forca.json', JSON.stringify(forca, null, 2))
enviar(`*Você perdeu o jogo!❌*\n\n${puppet[attempts]}\n\n*Palavra: ${str_under.split('').join(' ')}*\n*Suas chances se esgotaram*`)
} else {
enviar(`*Você errou!❌*\n\n${puppet[attempts]}\n\n*Palavra: ${str_under.split('').join(' ')}*\n*Você tem ${attempts} chances*`)
fs.writeFileSync('database/funções/grupos/forca.json', JSON.stringify(forca, null, 2))
}
    }
}
break

case 'jogodaforca':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
if (args.length < 1) return enviar('Ative pressione 1, Desativar pressione 0')
if(isPlayForca) return enviar(`*Termine a partida iniciada para jogar uma nova, ou dê o comando ${prefix}resetforca*`)
word_correct = (await randompalavra()).slice(1).normalize('NFD').replace(/[\u0300-\u036f]/g, "").toLowerCase()
under_word = '-'.repeat(word_correct.length)
forca.push({
    id: sender,
    word_original: word_correct,
    word: word_correct,
    under_word: under_word,
    array_word: Array.from(word_correct),
    array_under_word: Array.from(under_word),
    tam: word_correct.length,
    attempts: 6
})
fs.writeFileSync('database/funções/grupos/forca.json', JSON.stringify(forca, null, 2))
enviar(`*Jogo da forca iniciado!✅*\n\n*Palavra: ${under_word.split('').join(' ')}*\n*Para advinhar uma letra , dê o comando ${prefix}forca mais a letra*`)
break

case 'cartafofa':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
txt = body.slice(11)
txtt = args.join(" ")
txt1 = txt.split("/")[0];
txt2 = txtt.split("/")[1];
if(!txt) return enviar('Cade o número da pessoa?')
if(!txtt) return enviar('Cade a mensagem do correio??')
if(txt.includes("-")) return enviar('Tem que ser o número junto sem +, e não pode tá separado da /')
if(txtt.includes("+")) return enviar('Tem que ser o número junto sem +, e não pode tá separado da /')
if(!txtt.includes("/")) return enviar(`Exemplo: ${prefix + command} 554799544862/Theus é o millior`)
bla = 
`
╭═──── ⟮ ۝ ⟯ ────═༻
┃     𝘊𝘰𝘳𝘳𝘦𝘪𝘰 𝘌𝘭𝘦𝘨𝘢𝘯𝘵𝘦
┃           ⟮💌⟯ 
┃𝘔𝘦𝘯𝘴𝘢𝘨𝘦𝘮: ${txt2}
╰═─── ⟮ ۝ ⟯ ─────═༻`
theus.sendMessage(`${txt1}@s.whatsapp.net`, {text: bla})
break

case 'carta':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
txt = body.slice(7)
txtt = args.join(" ")
txt1 = txt.split("/")[0];
txt2 = txtt.split("/")[1];
if(!txt) return enviar('Cade o número da pessoa?')
if(!txtt) return enviar('Cade a mensagem do correio??')
if(txt.includes("-")) return enviar('Tem que ser o número junto sem +, e não pode tá separado da /')
if(txtt.includes("+")) return enviar('Tem que ser o número junto sem +, e não pode tá separado da /')
if(!txtt.includes("/")) return enviar(`Exemplo: ${prefix + command} 554799544862/Theus é o millior`)
bla = 
`
╭═──── ⟮ ۝ ⟯ ────═༻
┃     𝘝𝘰𝘤𝘦 𝘙𝘦𝘤𝘦𝘣𝘦𝘶 𝘜𝘮𝘢 𝘊𝘢𝘳𝘵𝘢
┃           ⟮📝⟯ 
┃𝘔𝘦𝘯𝘴𝘢𝘨𝘦𝘮: ${txt2}
╰═─── ⟮ ۝ ⟯ ─────═༻`
theus.sendMessage(`${txt1}@s.whatsapp.net`, {text: bla})
break

case 'gay':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')


rate = body.slice(5)
enviar(' Pesquisando a sua ficha de gay : '+rate+' aguarde...')
 setTimeout(async() => {
wew = await getBuffer(`${meno2}`)
zxzz = 
random = `${Math.floor(Math.random() * 110)}`
feio = random
boiola = random
if (boiola < 20 ) {bo = 'hmm... você é hetero😔'} else if (boiola == 21 ) {bo = '+/- boiola'} else if (boiola == 23 ) {bo = '+/- boiola'} else if (boiola == 24 ) {bo = '+/- boiola'} else if (boiola == 25 ) {bo = '+/- boiola'} else if (boiola == 26 ) {bo = '+/- boiola'} else if (boiola == 27 ) {bo = '+/- boiola'} else if (boiola == 2 ) {bo = '+/- boiola'} else if (boiola == 29 ) {bo = '+/- boiola'} else if (boiola == 30 ) {bo = '+/- boiola'} else if (boiola == 31 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 32 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 33 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 34 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 35 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 36 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 37 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 3 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 39 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 40 ) {bo = 'tenho minha desconfiança...😑'} else if (boiola == 41 ) {bo = 'você é né?😏'} else if (boiola == 42 ) {bo = 'você é né?😏'} else if (boiola == 43 ) {bo = 'você é né?😏'} else if (boiola == 44 ) {bo = 'você é né?😏'} else if (boiola == 45 ) {bo = 'você é né?😏'} else if (boiola == 46 ) {bo = 'você é né?😏'} else if (boiola == 47 ) {bo = 'você é né?😏'} else if (boiola == 4 ) {bo = 'você é né?😏'} else if (boiola == 49 ) {bo = 'você é né?😏'} else if (boiola == 50 ) {bo = 'você é ou não?🧐'} else if (boiola > 51) {bo = 'você é gay🙈'
}
await theus.sendMessage(from, {image: wew, caption: 'O Quanto Você É Gay?\nVocê é: '+random+'% gay 🏳️‍🌈\n'+bo+' ', thumbnail:null}, {quoted: selo2})
}, 7000)
break

case 'feio':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

rate = body.slice(6)
enviar('Pesquisando a sua ficha de feio : '+rate+'Aguarde...')
 setTimeout(async() => {
wew = await getBuffer(`${logo5}`)
zxzz = 
random = `${Math.floor(Math.random() * 110)}`
feio = random
if (feio < 20 ) {bo = 'É não é feio'} else if (feio == 21 ) {bo = '+/- feio'} else if (feio == 23 ) {bo = '+/- feio'} else if (feio == 24 ) {bo = '+/- feio'} else if (feio == 25 ) {bo = '+/- feio'} else if (feio == 26 ) {bo = '+/- feio'} else if (feio == 27 ) {bo = '+/- feio'} else if (feio == 2 ) {bo = '+/- feio'} else if (feio == 29 ) {bo = '+/- feio'} else if (feio == 30 ) {bo = '+/- feio'} else if (feio == 31 ) {bo = 'Ainda tá na média'} else if (feio == 32 ) {bo = 'Da pra pegar umas(ns) novinha(o) ainda'} else if (feio == 33 ) {bo = 'Da pra pegar umas(ns) novinha(o) ainda'} else if (feio == 34 ) {bo = 'É fein, mas tem baum coração'} else if (feio == 35 ) {bo = 'Tá na média, mas não deixa de ser feii'} else if (feio == 36 ) {bo = 'Bonitin mas é feio com orgulho'} else if (feio == 37 ) {bo = 'Feio e preguiçoso(a), vai se arrumar praga feia'} else if (feio == 3 ) {bo = 'tenho '} else if (feio == 39 ) {bo = 'Feio, mas um banho E se arrumar, deve resolver'} else if (feio == 40 ) {bo = 'FeiN,  mas não existe gente feia, existe gente que não conhece os produtos jequity'} else if (feio == 41 ) {bo = 'você é Feio, mas é legal, continue assim'} else if (feio == 42 ) {bo = 'Nada que uma maquiagem e se arrumar, que não resolva 🥴'} else if (feio == 43 ) {bo = 'Feio que dói de ver, compra uma máscara que melhora'} else if (feio == 44 ) {bo = 'Feio mas nada que um saco na cabeça não resolva né!?'} else if (feio == 45 ) {bo = 'você é feio, mas tem bom gosto'} else if (feio == 46 ) {bo = 'Feio mas tem muitos amigos'} else if (feio == 47 ) {bo = 'Feio mas tem lábia pra pegar várias novinha'} else if (feio == 4 ) {bo = 'Feio e ainda não sabe se vestir, vixi'} else if (feio == 49 ) {bo = 'Feiooo'} else if (feio == 50 ) {bo = 'você é Feio, mas não se encherga 🧐'} else if (feio > 51) {bo = 'você é Feio demais 🙈'} 

await theus.sendMessage(from, {image: wew, caption: '  O quanto você é feio? \n\n 「 '+rate+' 」Você é: '+random+'%  feio\n\n '+bo+' '}, {quoted: info})
 }, 7000)
break 

case 'matar':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return enviar('marque o alvo que você quer matar')
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
pru = '.\n'
for (let _ of mentioned) {
pru += `@${_.split('@')[0]}\n`
}
susp = `Você Acabou de matar o(a) @${mentioned[0].split('@')[0]} 🔪` 
jrpp = await getBuffer(`${level}`)
await theus.sendMessage(from, {video: jrpp, gifPlayback: true, caption: susp}, {quoted: info})
break 

case 'corno':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

rate = body.slice(7)
enviar(resposta.toy)
setTimeout(async() => {
wew = await getBuffer(`${logo2}`)
zxzz = 
random = `${Math.floor(Math.random() * 110)}`
await theus.sendMessage(from, {image: wew, caption: '  O quanto você é corno? \n\n 「 '+rate+' 」Você é:  '+random+'%   corno 🐃'}, { quoted: info})
}, 7000)
break

case 'vesgo':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

rate = body.slice(7)
enviar(resposta.toy)
setTimeout(async() => {
wew = await getBuffer(`${logo6}`)
zxzz = 
random = `${Math.floor(Math.random() * 110)}`
await theus.sendMessage(from, {image: wew, caption: 'O quanto você é vesgo? \n\n「 '+rate+' 」Você é: '+random+'%   Vesgo 🙄😆'}, {quoted: info})
}, 7000)
break 

case 'bebado':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

rate = body.slice(7)
enviar(resposta.toy)
setTimeout(async() => {
wew = await getBuffer(`${logo5}`)
zxzz = 
random = `${Math.floor(Math.random() * 110)}`
await theus.sendMessage(from, {image: wew, caption: 'O quanto você é bebado? \n\n「 '+rate+' 」Você é:  '+random+'%  Bêbado 🤢🥵🥴'}, {quoted: info})
}, 7000)
break 

case 'gado':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

rate = body.slice(6)
enviar(resposta.toy)
setTimeout(async() => {
wew = await getBuffer(`${logo4}`)
zxzz = 
random = `${Math.floor(Math.random() * 110)}`
await theus.sendMessage(from, {image: wew, caption: 'O quanto você é gado? \n\n「 '+rate+' 」Você é: '+random+'%  gado 🐂'}, {quoted: info})
}, 7000)
break 

case 'gostoso':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

rate = body.slice(9)
enviar(resposta.toy)
setTimeout(async() => {
wew = await getBuffer(`${logo3}`)
zxzz = 
random = `${Math.floor(Math.random() * 110)}`
await theus.sendMessage(from, {image: wew, caption: '  O quanto você é gostoso? 😏\n\n「 '+rate+' 」Você é: '+random+'%  gostoso 😝', gifPlayback: true}, {quoted: info})
}, 7000)
break 

case 'gostosa':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

rate = body.slice(9)
enviar(resposta.toy)
setTimeout(async() => {
wew = await getBuffer(`${logo2}`)
zxzz = 
random = `${Math.floor(Math.random() * 110)}`
await theus.sendMessage(from, {image: wew, caption: 'O quanto você é gostosa? 😏\n\n「 '+rate+' 」Você é:  '+random+'%  gostosa 😳'}, {quoted: info})
}, 7000)
break

case 'beijo':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return enviar('Marque alguém que vc quer da um beijo')
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
pru = '.\n'
for (let _ of mentioned) {
pru += `@${_.split('@')[0]}\n`
}
susp = `Você deu um beijo gostoso na(o) @${mentioned[0].split('@')[0]} 😁👉👈❤` 
wew = await getBuffer(`${meno2}`)
await theus.sendMessage(from, {video: wew, gifPlayback: true, caption: susp}, {quoted: info})
break

case 'tapa':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return enviar('marque o alvo que você quer dá o tapa')
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
pru = '.\n'
for (let _ of mentioned) {
pru += `@${_.split('@')[0]}\n`
}
susp = `Você Acabou de da um tapa na raba da😏 @${mentioned[0].split('@')[0]} 🔥` 
jrq = await getBuffer(`${logo5}`)
await theus.sendMessage(from, {video: jrq, gifPlayback: true, caption: susp}, {quoted: info})
break

case 'chute': case 'chutar':  
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

if (info.message.extendedTextMessage === undefined || info.message.extendedTextMessage === null) return enviar('marque o alvo que você quer dá um chute')
mentioned = info.message.extendedTextMessage.contextInfo.mentionedJid
pru = '.\n'
for (let _ of mentioned) {
pru += `@${_.split('@')[0]}\n`
}
susp = `Você Acabou de da um chute em @${mentioned[0].split('@')[0]} [🩸]` 
jry = await getBuffer(`${logo2}`)
await theus.sendMessage(from, {video: jry, gifPlayback: true, caption: susp}, {quoted: info})
break 

case 'dogolpe':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')
if (args.length < 1) return await theus.sendMessage(from, {text: 'Marque a Pessoa'}, {quoted: info})
pkt = body.slice(9)
random = `${Math.floor(Math.random() * 100)}`
jpr = `*GOLPISTA ENCONTRADO👉🏻*\n\n*GOLPISTA* : *${args[0]}*\n*PORCENTAGEM DO GOLPE* : ${random}%😂\n\nEle(a) gosta de ferir sentimentos 😢`
enviar(jpr)
break

case 'shipo':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

teks = args.join(" ")
if(teks.length < 10) return enviar('Marque uma pessoa do grupo para encontrar o par dela')
membrr = []
const suamae111 = groupMembers
const suamae211 = groupMembers
const teupai111 = suamae111[Math.floor(Math.random() * suamae111.length)]
const teupai211 = suamae211[Math.floor(Math.random() * suamae211.length)]
var shipted1 = ["1%", `2%`, `3%`, `4%`, `5%`, `6%`, `7`, `%`, `9%`, `10`, `11%`, `12%`,`13%`, `14%`, `15%`, `16%`, `17%`, `1%`, `19%`, `20%`, `21%`, `22`, `23%`, `24%`, `25%`, `26%`, `27%`, `2%`, `27%`, `2%`, `29%`, `30%`, `31%`, `32%`, `33%`, `34%`, `35%`, `36%`, `37%`, `3%`, `39%`, `40%`, `41%`, `42%`, `43%`, `44%`, `45%`, `46%`, `47%`, `4%`, `49%`, `50%`, `51%`, `52%`, `53%`, `54%`, `55%`, `56%`, `57%`, `5%`, `59%`, `60%`, `61%`, `62%`, `63%`, `64%`, `65%`, `66%`, `67%`, `6%`, `69%`, `70%`, `71%`, `72%`, `73%`, `74%`, `75%`, `76%`, `77%`, `7%`, `79%`, `0%`, `1%`, `2%`, `5%`, `4%`, `5%`, `6%`, `7%`, `%`, `9%`, `90%`, `91%`, `92%`, `93%`, `94%`, `95%`, `96%`, `97%`, `9%`, `99%`, `100%`]
const shiptedd = shipted1[Math.floor(Math.random() * shipted1.length)]
jet = `*Q Fofo.... Eu Shipo eles 2*\n\n1 = @${teupai111.id.split('@')[0]}\n && 2 = ${teks} com uma porcentagem de: ${shiptedd}`
membrr.push(teupai111.id)
membrr.push(teupai211.id)
mentions(jet, membrr, true)
break

case 'casal':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

membr = []
const suamae11 = groupMembers
const suamae21 = groupMembers
const teupai11 = suamae11[Math.floor(Math.random() * suamae11.length)]
const teupai21 = suamae21[Math.floor(Math.random() * suamae21.length)]
var shipted1 = ["1%", `2%`, `3%`, `4%`, `5%`, `6%`, `7`, `%`, `9%`, `10`, `11%`, `12%`,`13%`, `14%`, `15%`, `16%`, `17%`, `1%`, `19%`, `20%`, `21%`, `22`, `23%`, `24%`, `25%`, `26%`, `27%`, `2%`, `27%`, `2%`, `29%`, `30%`, `31%`, `32%`, `33%`, `34%`, `35%`, `36%`, `37%`, `3%`, `39%`, `40%`, `41%`, `42%`, `43%`, `44%`, `45%`, `46%`, `47%`, `4%`, `49%`, `50%`, `51%`, `52%`, `53%`, `54%`, `55%`, `56%`, `57%`, `5%`, `59%`, `60%`, `61%`, `62%`, `63%`, `64%`, `65%`, `66%`, `67%`, `6%`, `69%`, `70%`, `71%`, `72%`, `73%`, `74%`, `75%`, `76%`, `77%`, `7%`, `79%`, `0%`, `1%`, `2%`, `5%`, `4%`, `5%`, `6%`, `7%`, `%`, `9%`, `90%`, `91%`, `92%`, `93%`, `94%`, `95%`, `96%`, `97%`, `9%`, `99%`, `100%`]
const shipted = shipted1[Math.floor(Math.random() * shipted1.length)]
jet = `*Q Fofoss.... Eu Shipo eles 2*\n\n1= @${teupai11.id.split('@')[0]}\ne esse\n2= @${teupai21.id.split('@')[0]}\ncom uma porcentagem de: ${shipted}`
membr.push(teupai11.id)
membr.push(teupai21.id)
mentions(jet, membr, true)
break

case 'nazista':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

rate = body.slice(9)
enviar(resposta.toy)
setTimeout(async() => {
wew = await getBuffer(`${selo2}`)
zxzz = 
random = `${Math.floor(Math.random() * 110)}`
await theus.sendMessage(from, {image: wew, caption: 'O quanto você é nazista? \n\n「 '+rate+' 」Você é: ❰ '+random+'% ❱  nazista 卐'}, {quoted: info})
}, 7000)
break 

case 'rankgay':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

try{
d = []
ret = '🏳️‍🌈 Rank dos mais gays\n'
for(i = 0; i < 5; i++) {
r = Math.floor(Math.random() * groupMetadata.participants.length + 0)
ret += `🏳️‍🌈❧ @${groupMembers[r].id.split('@')[0]}\n`
d.push(groupMembers[r].id)
}
mentions(ret, d, true)
} catch (e) {
console.log(e)
enviar('Deu erro, tente novamente :/')
}
break

case 'rankgado': case 'rankgados':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

try{
d = []
ret = '🐂🐂 Rank dos mais gados do grupo \n'
for(i = 0; i < 5; i++) {
r = Math.floor(Math.random() * groupMetadata.participants.length + 0)
ret += `🐂❧ @${groupMembers[r].id.split('@')[0]}\n`
d.push(groupMembers[r].id)
}
mentions(ret, d, true)
} catch (e) {
console.log(e)
enviar('Deu erro, tente novamente :/')
}
break

case 'rankcorno': case 'rankcornos':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

membr = []
const corno1 = groupMembers
const corno2 = groupMembers
const corno3 = groupMembers
const corno4 = groupMembers
const corno5 = groupMembers
const cornos1 = corno1[Math.floor(Math.random() * corno1.length)]
const cornos2 = corno2[Math.floor(Math.random() * corno2.length)]
const cornos3 = corno3[Math.floor(Math.random() * corno3.length)]
const cornos4 = corno4[Math.floor(Math.random() * corno4.length)]
const cornos5 = corno5[Math.floor(Math.random() * corno5.length)]
var porcentagemcorno = ["1%", `2%`, `3%`, `4%`, `5%`, `6%`, `7`, `%`, `9%`, `10`, `11%`, `12%`,`13%`, `14%`, `15%`, `16%`, `17%`, `1%`, `19%`, `20%`, `21%`, `22`, `23%`, `24%`, `25%`, `26%`, `27%`, `2%`, `27%`, `2%`, `29%`, `30%`, `31%`, `32%`, `33%`, `34%`, `35%`, `36%`, `37%`, `3%`, `39%`, `40%`, `41%`, `42%`, `43%`, `44%`, `45%`, `46%`, `47%`, `4%`, `49%`, `50%`, `51%`, `52%`, `53%`, `54%`, `55%`, `56%`, `57%`, `5%`, `59%`, `60%`, `61%`, `62%`, `63%`, `64%`, `65%`, `66%`, `67%`, `6%`, `69%`, `70%`, `71%`, `72%`, `73%`, `74%`, `75%`, `76%`, `77%`, `7%`, `79%`, `0%`, `1%`, `2%`, `5%`, `4%`, `5%`, `6%`, `7%`, `%`, `9%`, `90%`, `91%`, `92%`, `93%`, `94%`, `95%`, `96%`, `97%`, `9%`, `99%`, `O chifre desse ai bate na lua ksksksk`]
const porcentagemc = porcentagemcorno[Math.floor(Math.random() * porcentagemcorno.length)]
const porcentag = porcentagemcorno[Math.floor(Math.random() * porcentagemcorno.length)]
const porcent = porcentagemcorno[Math.floor(Math.random() * porcentagemcorno.length)]
const porcl = porcentagemcorno[Math.floor(Math.random() * porcentagemcorno.length)]
const porg = porcentagemcorno[Math.floor(Math.random() * porcentagemcorno.length)]
const prg = porcentagemcorno[Math.floor(Math.random() * porcentagemcorno.length)]
ytb = `
Esses são os cornos do grupo ${groupName}\n@${cornos1.id.split('@')[0]}\nCom uma porcentagem de ${porcent}\n@${cornos2.id.split('@')[0]}\nCom uma porcentagem de ${porcentag}\n@${cornos3.id.split('@')[0]}\nCom uma porcentagem de ${porcl}\n@${cornos4.id.split('@')[0]}\nCom uma porcentagem de ${porg}\n@${cornos5.id.split('@')[0]}\nCom uma porcentagem de ${prg}\n\n${nomeBot}`
membr.push(cornos1.id)
membr.push(cornos2.id)
membr.push(cornos3.id)
membr.push(cornos4.id)
membr.push(cornos5.id)
mentions(ytb, membr, true)
break

case 'rankgostosos': case 'rankgostoso':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

member = []
const p01 = groupMembers
const p02 = groupMembers
const p03 = groupMembers
const p04 = groupMembers
const p05 = groupMembers
const o01 = p01[Math.floor(Math.random() * p01.length)]
const o02 = p02[Math.floor(Math.random() * p02.length)]
const o03 = p03[Math.floor(Math.random() * p03.length)]
const o04 = p04[Math.floor(Math.random() * p04.length)]
const o05 = p05[Math.floor(Math.random() * p05.length)]
luy = `
Parados!🤚🤚\n\n1=🤚🤭@${o01.id.split('@')[0]}🤚🤭\n\n\n2=🤚🤭@${o02.id.split('@')[0]}🤚🤭\n\n\n3=🤚🤭@${o03.id.split('@')[0]}🤚🤭\n\n\n4=🤚🤭@${o04.id.split('@')[0]}🤚🤭\n\n\n5=🤚🤭@${o05.id.split('@')[0]}🤚🤭\n\n\nMulta por serem gostosos dms😳 pague pena trabalhando em nossa agência de modelos 😊 by: ${nomeBot}`
member.push(o01.id)
member.push(o02.id)
member.push(o03.id)
member.push(o04.id)
member.push(o05.id)
mentions(luy, member, true)
break

case 'rankgostosas': case 'rankgostosa':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

member = []
const p1 = groupMembers
const p2 = groupMembers
const p3 = groupMembers
const p4 = groupMembers
const p5 = groupMembers
const o1 = p1[Math.floor(Math.random() * p1.length)]
const o2 = p2[Math.floor(Math.random() * p2.length)]
const o3 = p3[Math.floor(Math.random() * p3.length)]
const o4 = p4[Math.floor(Math.random() * p4.length)]
const o5 = p5[Math.floor(Math.random() * p5.length)]
luy = `
Paradas!🤚🤚\n\n1=🤚🤭@${o1.id.split('@')[0]}🤚🤭\n\n\n2=🤚🤭@${o2.id.split('@')[0]}🤚🤭\n\n\n3=🤚🤭@${o3.id.split('@')[0]}🤚🤭\n\n\n4=🤚🤭@${o4.id.split('@')[0]}🤚🤭\n\n\n5=🤚🤭@${o5.id.split('@')[0]}🤚🤭\n\n\nMultas por serem gostosas dms😳 pague pena enviando nud no PV do dono😊 by Bot`
member.push(o1.id)
member.push(o2.id)
member.push(o3.id)
member.push(o4.id)
member.push(o5.id)
mentions(luy, member, true)
break

case 'ranknazista':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

try{
d = []
teks = '💂‍♂️Rank dos mais nazistas do gp\n'
for(i = 0; i < 5; i++) {
r = Math.floor(Math.random() * groupMetadata.participants.length + 0)
teks += `💂‍♂️❧ @${groupMembers[r].id.split('@')[0]}\n`
d.push(groupMembers[r].id)
}
mentions(teks, d, true)
} catch (e) {
console.log(e)
enviar('Deu erro, tente novamente :/')
}
break

case 'rankotakus':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')


membr = []
const otaku1 = groupMembers
const otaku2 = groupMembers
const otaku3 = groupMembers
const otaku4 = groupMembers
const otaku5 = groupMembers
const otaku6 = groupMembers
const otaku7 = groupMembers
const otaku = groupMembers
const otaku9 = groupMembers
const otaku10 = groupMembers
const otakus1 = otaku1[Math.floor(Math.random() * otaku1.length)]
const otakus2 = otaku2[Math.floor(Math.random() * otaku2.length)]
const otakus3 = otaku3[Math.floor(Math.random() * otaku3.length)]
const otakus4 = otaku4[Math.floor(Math.random() * otaku4.length)]
const otakus5 = otaku5[Math.floor(Math.random() * otaku5.length)]
const otakus6 = otaku6[Math.floor(Math.random() * otaku6.length)]
const otakus7 = otaku7[Math.floor(Math.random() * otaku7.length)]
const otakus = otaku[Math.floor(Math.random() * otaku.length)]
const otakus9 = otaku9[Math.floor(Math.random() * otaku9.length)]
const otakus10 = otaku10[Math.floor(Math.random() * otaku10.length)]
ytb = `esses são os otakus fedidos do grupo\n@${otakus1.id.split('@')[0]}\n@${otakus2.id.split('@')[0]}\n@${otakus3.id.split('@')[0]}\n@${otakus4.id.split('@')[0]}\n@${otakus5.id.split('@')[0]}\n@${otakus6.id.split('@')[0]}\n@${otakus7.id.split('@')[0]}\n@${otakus.id.split('@')[0]}\n@${otakus9.id.split('@')[0]}\n@${otakus10.id.split('@')[0]}\n\n ${nomeBot} `
membr.push(otakus1.id)
membr.push(otakus2.id)
membr.push(otakus3.id)
membr.push(otakus4.id)
membr.push(otakus5.id)
membr.push(otakus6.id)
membr.push(otakus7.id)
membr.push(otakus.id)
membr.push(otakus9.id)
membr.push(otakus10.id)
mentions(ytb, membr, true)
break

case 'rankpau':
if (!isRegistro) return enviar(resposta.login)
if (!isGroup) return enviar('Só em Grupo')

membr = []
const pauz1 = groupMembers
const pauz2 = groupMembers
const pauz3 = groupMembers
const pauz4 = groupMembers
const pauz5 = groupMembers
const paus1 = pauz1[Math.floor(Math.random() * pauz1.length)]
const paus2 = pauz2[Math.floor(Math.random() * pauz2.length)]
const paus3 = pauz3[Math.floor(Math.random() * pauz3.length)]
const paus4 = pauz4[Math.floor(Math.random() * pauz4.length)]
const paus5 = pauz5[Math.floor(Math.random() * pauz5.length)]
var pcpau1 = ["Minuscúlo", `Pequenino`, `Pequeno`, `Médio`, `Grandinho`, `Grande`, `Grandão`, `Gigante`, `Gigantesco`, `Enorme`, `BATENDO NA LUA`, `QUEIMADO, TÃO GRANDE QUE BATEU NO SOL E QUEIMOU ksksksk`]
var pcpau2 = ["Minuscúlo", `Pequenino`, `Pequeno`, `Médio`, `Grandinho`, `Grande`, `Grandão`, `Gigante`, `Gigantesco`, `Enorme`, `BATENDO NA LUA`, `QUEIMADO, TÃO GRANDE QUE BATEU NO SOL E QUEIMOU ksksksk`]
var pcpau3 = ["Minuscúlo", `Pequenino`, `Pequeno`, `Médio`, `Grandinho`, `Grande`, `Grandão`, `Gigante`, `Gigantesco`, `Enorme`, `BATENDO NA LUA`, `QUEIMADO, TÃO GRANDE QUE BATEU NO SOL E QUEIMOU ksksksk`]
var pcpau4 = ["Minuscúlo", `Pequenino`, `Pequeno`, `Médio`, `Grandinho`, `Grande`, `Grandão`, `Gigante`, `Gigantesco`, `Enorme`, `BATENDO NA LUA`, `QUEIMADO, TÃO GRANDE QUE BATEU NO SOL E QUEIMOU ksksksk`]
var pcpau5 = ["Minuscúlo", `Pequenino`, `Pequeno`, `Médio`, `Grandinho`, `Grande`, `Grandão`, `Gigante`, `Gigantesco`, `Enorme`, `BATENDO NA LUA`, `QUEIMADO, TÃO GRANDE QUE BATEU NO SOL E QUEIMOU ksksksk`]
const pc1 = pcpau1[Math.floor(Math.random() * pcpau1.length)]
const pc2 = pcpau2[Math.floor(Math.random() * pcpau2.length)]
const pc3 = pcpau3[Math.floor(Math.random() * pcpau3.length)]
const pc4 = pcpau4[Math.floor(Math.random() * pcpau4.length)]
const pc5 = pcpau5[Math.floor(Math.random() * pcpau5.length)]
pdr = `Esses são os caras com o menor e maior pau do Grupo\n${groupName}\n\n@${paus1.id.split('@')[0]}\n${pc1}\n@${paus2.id.split('@')[0]}\n${pc2}\n@${paus3.id.split('@')[0]}\n${pc3}\n@${paus4.id.split('@')[0]}\n${pc4}\n@${paus5.id.split('@')[0]}\n${pc5}\n\n ${nomeBot}`
membr.push(paus1.id)
membr.push(paus2.id)
membr.push(paus3.id)
membr.push(paus4.id)
membr.push(paus5.id)
mentions(pdr, membr, true)
break 


//FIM DAS CASES >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<
default:

// BOT RESPONDE SEM PREFIXO
if (budy.includes('prefixo') || (budy.includes('Prefixo'))){
enviar(`Olá "${pushname}" Que Bom Ver Novas Pessoas Por Aqui, Bom Meu Prefixo é"${prefix}" Digite: "${prefix}menu"`)
}

if (budy.includes('Oi') || (budy.includes('oi'))){
enviar(`Olá "${pushname}" Como Você Esta?`)
}

if (budy.includes('Estou Bem') || (budy.includes('estou bem'))){
enviar(`Que Bom Que Você Esta Bem!`)
}

if (budy.includes('theus') || (budy.includes('Theus'))){
enviar(`O Que Ce Quer Com Meu Amado Dono?`)
}

if (budy.includes(`bot`) || (budy.includes(`Bot`))){
enviar(`Oii "${pushname}" Estou Aqui!`)
console.log(color('AUTO RESPOSTA', 'white'))
}

if (isCmd){
theus.sendMessage(from, {text: `╭───────────\n│Olá "${pushname}"\n│Não Encontrei Este Comando\n│Clique No Botão Abaixo\n│Ou digite "${prefixo}menu"\n│Data Do Erro: ${data}\n╰───────────`, footer: 'MoPi-BOT', buttons: [{buttonId: `${prefixo}menu`, buttonText: {displayText: 'Menu'}, type: 1}, ]}, {quoted: selotempoonline})
return
}



switch(ants){
} 


}
} catch (e) {
console.log(e)
}
})
}
//OQUE APARECE NO TERMUX AO MODIFICAR A INDEX.JS >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<
fs.watchFile('./index.js', (curr, prev) => {
if (curr.mtime.getTime() !== prev.mtime.getTime()) {
console.log(color("A index.js ACABOU DE SER MODIFICADA, REINICIANDO...", "yellow"));
process.exit()
}
})




//
startmopi()

// BASE DO DA CORO PASSEM NO CANAL DELE >>>>>>>>>>>>>MoPi<<<<<<<<<<<<<<<